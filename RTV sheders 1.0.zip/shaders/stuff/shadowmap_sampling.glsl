// Shadow-map sampling, classic Minecraft style:
//   * linear shadow projection (see shadowmap_distortion.glsl)
//   * normal-offset + slope-scaled depth bias
//   * fixed 3x3 PCF, so the edge never rotates or jitters with temporal noise
//   * optional coloured shadows from translucent casters
// get_shadows_at_foot_pos() returns the VISIBILITY of the sun (0 = shadow, 1 = lit, tinted by glass).
// It does NOT contain the N.L (lambert) term, callers multiply that in themselves.
uniform sampler2D shadowcolor0;
uniform sampler2D shadowtex0; //all casters, including translucent ones
uniform sampler2D shadowtex1; //opaque casters only
const bool shadowcolor0Nearest = true;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;

// World size (in blocks) of one shadow-map texel at this position, taking the distortion into account.
float rtv_shadow_texel_world(in vec2 ndc_xy)
{
	#ifdef SHADOW_DISTORT_ENABLED
		float k = length(ndc_xy) + SHADOW_DISTORT_FACTOR;
		float distortion_scale = k * k / (SHADOW_DISTORT_FACTOR * (1.0 + SHADOW_DISTORT_FACTOR));
	#else
		float distortion_scale = 1.0;
	#endif
	return (2.0 / float(shadowMapResolution)) / abs(shadowProjection[0][0]) * distortion_scale;
}

// Smooth PCF: the shadow map is read with nearest filtering, so a plain 3x3 box gives only 10 gray levels and the
// shadow edge shows up as stair steps one texel wide (very visible on the sea floor seen through water).
// Here two 3x3 boxes that are one grid step apart are blended by the fractional position of the lookup, so the
// shadow value changes continuously while the point moves. 16 taps instead of 9.
float rtv_pcf_smooth(in sampler2D shadow_tex, in vec3 shadow_pos, in float radius_uv)
{
	vec2 g = shadow_pos.xy / radius_uv - 0.5;
	vec2 b = floor(g);
	vec2 f = g - b;
	float b00 = 0.0, b10 = 0.0, b01 = 0.0, b11 = 0.0;
	for (int j = 0; j < 4; j++)
	{
		for (int i = 0; i < 4; i++)
		{
			vec2 uv = clamp((b + vec2(float(i - 1), float(j - 1)) + 0.5) * radius_uv, vec2(0.001), vec2(0.999));
			float v = step(shadow_pos.z, texture(shadow_tex, uv).r);
			if (i <= 2 && j <= 2) b00 += v;
			if (i >= 1 && j <= 2) b10 += v;
			if (i <= 2 && j >= 1) b01 += v;
			if (i >= 1 && j >= 1) b11 += v;
		}
	}
	return mix(mix(b00, b10, f.x), mix(b01, b11, f.x), f.y) / 9.0;
}

// Fraction of the filter kernel that can see the sun, looking at OPAQUE casters only.
// A fixed grid deliberately replaces the rotating Vogel disk: it is stable on
// thin geometry and preserves the actual block silhouette and shadow direction.
float rtv_shadow_visibility_opaque(in vec3 shadow_pos, in float radius_uv, in float phi)
{
	#if SOFT_SHADOWMAP_SHADOWS == 1 && SHADOW_SMOOTH_PCF == 1
		return rtv_pcf_smooth(shadowtex1, shadow_pos, radius_uv);
	#elif SOFT_SHADOWMAP_SHADOWS == 1
		float lit = 0.0;
		for (int x = -1; x <= 1; x++)
		{
			for (int y = -1; y <= 1; y++)
			{
				vec2 uv = clamp(shadow_pos.xy + vec2(float(x), float(y)) * radius_uv, vec2(0.001), vec2(0.999));
				lit += step(shadow_pos.z, texture(shadowtex1, uv).r);
			}
		}
		return lit / 9.0;
	#else
		return step(shadow_pos.z, texture(shadowtex1, clamp(shadow_pos.xy, vec2(0.001), vec2(0.999))).r);
	#endif
}

// Same, but looking at ALL casters (opaque + translucent)
float rtv_shadow_visibility_all(in vec3 shadow_pos, in float radius_uv, in float phi)
{
	#if SOFT_SHADOWMAP_SHADOWS == 1 && SHADOW_SMOOTH_PCF == 1
		return rtv_pcf_smooth(shadowtex0, shadow_pos, radius_uv);
	#elif SOFT_SHADOWMAP_SHADOWS == 1
		float lit = 0.0;
		for (int x = -1; x <= 1; x++)
		{
			for (int y = -1; y <= 1; y++)
			{
				vec2 uv = clamp(shadow_pos.xy + vec2(float(x), float(y)) * radius_uv, vec2(0.001), vec2(0.999));
				lit += step(shadow_pos.z, texture(shadowtex0, uv).r);
			}
		}
		return lit / 9.0;
	#else
		return step(shadow_pos.z, texture(shadowtex0, clamp(shadow_pos.xy, vec2(0.001), vec2(0.999))).r);
	#endif
}

vec3 get_shadows_at_foot_pos(in vec3 foot_pos, in vec3 normals_face_world, in vec3 dither_offset, in float sss, in float sun_lighting)
{
	vec3 shadow_ndc = foot_pos_to_shadow_ndc(foot_pos);
	float texel_world = rtv_shadow_texel_world(shadow_ndc.xy);

	// How much the surface faces away from the sun. Grazing surfaces need more bias.
	float n_dot_l = clamp(sun_lighting, 0.0, 1.0);
	float slope = min(sqrt(max(1.0 - n_dot_l * n_dot_l, 0.0)) / max(n_dot_l, 0.15), 4.0);

	// 1. Normal offset: push the lookup position out of the surface by about a texel.
	vec3 offset_pos = foot_pos;
	#ifdef NORMAL_BIAS
		offset_pos += normals_face_world * (texel_world * (1.0 + 2.0 * (1.0 - n_dot_l)) * SHADOW_BIAS);
	#endif

	vec3 shadow_pos = foot_pos_to_shadowmap_texcoord(offset_pos);

	// 2. Depth bias, in blocks, converted to shadow-map depth units. Translucent-ish surfaces (leaves, sss) get extra so light bleeds through.
	float bias_blocks = (0.01 + texel_world * 0.35 * slope) * SHADOW_BIAS + sss * 0.35;
	shadow_pos.z -= bias_blocks * 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);

	// 3. Outside of the shadow map there is nothing to compare with: lit. Fade in over the last 10% so there is no hard line.
	float edge = max(abs(shadow_pos.x * 2.0 - 1.0), abs(shadow_pos.y * 2.0 - 1.0));
	float inside = 1.0 - smoothstep(0.90, 1.0, edge);
	if (inside <= 0.001) return vec3(1.0);

	// 4. Fixed-grid PCF. No per-pixel / per-frame rotation: this removes shadow shimmer and crawling.
	float phi = 0.0;
	float radius_uv = SHADOW_SOFTNESS / float(shadowMapResolution);

	float visibility = rtv_shadow_visibility_opaque(shadow_pos, radius_uv, phi);
	vec3 light = vec3(visibility);

	// 5. Coloured shadows: where a translucent caster (glass, water) is in front of the opaque one, tint the light.
	#if COLORED_SHADOWS_SHADOWMAP == 1
		if (visibility > 0.001)
		{
			float visibility_all = rtv_shadow_visibility_all(shadow_pos, radius_uv, phi);
			float translucent_part = max(visibility - visibility_all, 0.0);
			if (translucent_part > 0.001)
			{
				vec4 caster_color = texture(shadowcolor0, clamp(shadow_pos.xy, vec2(0.001), vec2(0.999)));
				vec3 tint = mix(vec3(1.0), caster_color.rgb, pow(clamp(caster_color.a, 0.0, 1.0), GLASS_TINT_EXPONENT));
				light = vec3(visibility_all) + translucent_part * tint;
			}
		}
	#endif

	return mix(vec3(1.0), light, inside);
}
