// Ray traced block light (torches, lanterns, glowstone, lava, fire...). No vanilla light map is added anywhere.
// Uses the original voxel RT emissive-radiance model as its basis, with direct emitter sampling added for stable, visible coloured light.
//
// Every pixel searches the emitter grid and uses two weighted-reservoir samples to estimate nearby block light.
// Visibility rays preserve opaque solid-block shadows while partially transmitting through glass, water, ice and cutout geometry.
// The wider source/fade and multi-sample estimate soften abrupt circular cut-offs without expanding the configured light radius.
#include "/stuff/voxelizing/emitters.glsl"

#if RT_BLOCK_LIGHT_NEE == 1 && RT_API >= 6

// A compact emitter profile shared by placed lights, GI bounce and handheld lights.
// The cosine term models the receiving surface; inverse-square-like attenuation keeps
// light strongest near the source, while a soft edge avoids a visible spherical cutoff.
float rtv_block_light_sample_weight(in float level, in float distance_to_light, in float n_dot_l)
{
    float configured_radius = clamp(RT_BLOCK_LIGHT_RADIUS + RT_BLOCK_LIGHT_REACH * 2.0, 0.75, 12.0);
    float lvl = clamp(level / 15.0, 0.0, 1.0);
    // Keep dim emitters distinct, but let full-strength sources use the configured range.
    float source_radius = min(level * 0.65 + 0.90, configured_radius);
    float x = distance_to_light / max(source_radius, 0.5);
    // A broad, smooth shoulder carries useful light across caves without a hard sphere edge.
    float edge = 1.0 - smoothstep(0.82, 1.0, x);
    float window = edge * edge;
    // Slightly flatter than inverse-square: less hotspot near the emitter, more readable mid-range.
    float inverse_square = 1.0 / (0.80 + distance_to_light * distance_to_light * 0.20);
    float diffuse = pow(max(n_dot_l, 0.0), 0.90);
    return pow(lvl, 1.35) * diffuse * inverse_square * window;
}

// Flame flicker. Only coloured sources up to level 14 flicker (torch, soul torch, candles, redstone torch...);
// white lamps, glowstone, lava, lanterns and other level-15 blocks stay steady.
float rtv_emitter_flicker(in vec3 emitter_pos, in float level, in vec3 color)
{
    float peak = max(max(color.r, color.g), color.b);
    float saturation = (peak - min(min(color.r, color.g), color.b)) / max(peak, 0.001);
    float is_flame = step(level, 14.5) * step(1.5, level) * step(0.25, saturation);
    vec3 cell = floor(emitter_pos);
    float h = fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    float t = frameTimeCounter;
    float f = 0.55 * sin(t * 9.0 + h * 40.0) + 0.30 * sin(t * 17.3 + h * 91.0) + 0.15 * sin(t * 31.7 + h * 13.0);
    // Crying obsidian (level 10, purple): its light breathes slowly instead of flickering
    float is_purple = step(level, 10.5) * step(9.5, level) * step(1.25 * color.g, color.r) * step(1.25 * color.g, color.b);
    float pulse = 0.5 + 0.5 * sin(t * 1.6 + h * 6.2831);
    return 1.0 + is_flame * RT_BLOCK_LIGHT_FLICKER * 0.14 * f + is_purple * PULSING_BLOCKS * (pulse - 0.5) * 0.9;
}

// Trace one candidate emitter. The visibility ray now returns material transmittance,
// so cutout foliage and transparent glass/ice softly pass light instead of hard-clipping it.
vec3 rtv_block_light_visibility(in vec3 ray_start, in vec3 p_voxel, in vec3 emitter_pos, in vec3 jitter)
{
	// The flame is a very small area light.  Keeping this offset restrained avoids
	// temporal jitter on the edge of blocks while retaining a real penumbra.
	vec3 target = emitter_pos + jitter * (RT_BLOCK_LIGHT_SOFTNESS * 0.32);
	vec3 to_target = target - p_voxel;
	float target_dist = max(length(to_target), 0.001);
	vec3 target_dir = to_target / target_dist;

	// Stop at the near boundary of the emitter voxel, not at its occupied center.
	float major_dir = max(max(abs(target_dir.x), abs(target_dir.y)), abs(target_dir.z));
	float emitter_entry_distance = 0.5 / max(major_dir, 0.001);
	float visibility_limit = max(target_dist - emitter_entry_distance - 0.07, 0.0);

	if (visibility_limit <= 0.06) return vec3(1.0);

	Traced_shadow_ray light_ray = trace_light_ray(ray_start, target_dir, visibility_limit);
	// Direct emitter light is fully ray traced.  There is no vanilla or fake
	// around-the-corner fill here; any light behind an obstacle comes from GI.
	return light_ray.hit_something ? vec3(RT_BLOCK_LIGHT_WRAP) : clamp(light_ray.tint, vec3(0.0), vec3(1.0));
}

vec3 rtv_block_light_color_raw(in vec3 emitter_pos, in uint packed_emitter)
{
    // Dropped luminous items carry their own colour in the unused upper emitter bits.
    // This keeps a redstone torch red and soul lights blue even after the item moves.
    if ((packed_emitter & (1u << 21u)) != 0u)
    {
        vec3 item_rgb = vec3(
            float((packed_emitter >> 6u) & 31u),
            float((packed_emitter >> 11u) & 31u),
            float((packed_emitter >> 16u) & 31u)
        ) / 31.0;
        return max(item_rgb, vec3(0.0));
    }

    // Explicit source palettes keep placed light colours consistent with held items.
    // This is more reliable than the highest mip of animated or emissive block textures.
    uint source_type = (packed_emitter >> 23u) & 31u;
    vec3 mapped_source_color = rtv_mapped_block_light_color(source_type);
    if (max(max(mapped_source_color.r, mapped_source_color.g), mapped_source_color.b) > 0.0)
        return mapped_source_color;
	// Lava is animated and its highest mip can average toward a pale/yellow hue.
	if ((packed_emitter & (1u << 22u)) != 0u) return vec3(1.0, 0.24, 0.025);

	ivec3 emitter_voxel = ivec3(floor(emitter_pos));
	uint emitter_data = imageLoad(cimage1, emitter_voxel).r;

	// Restore RTV's normal torch spectrum. This is the fallback for emitters whose
	// voxel colour is unavailable; it is not a global warm filter.
	vec3 normal_torch = vec3(1.0, 0.76, 0.48);
	if (emitter_data == 0u) return normal_torch;

	// Preserve the actual chroma of saturated emitters. Redstone stays red and
	// cyan/blue sources stay cool; only neutral/unknown sources use the normal torch spectrum.
	vec3 source_albedo = max(unpack_albedo_from_voxel(emitter_data), vec3(0.0));
	float source_peak = max(max(source_albedo.r, source_albedo.g), max(source_albedo.b, 0.025));
	if (source_peak < 0.045) return normal_torch;

	vec3 source_chroma = clamp(source_albedo / source_peak, 0.0, 1.0);
	float source_min = min(source_albedo.r, min(source_albedo.g, source_albedo.b));
	float source_saturation = clamp((source_peak - source_min) / max(source_peak, 0.025), 0.0, 1.0);
	float hue_weight = smoothstep(0.06, 0.24, source_saturation);
	vec3 natural_source = mix(normal_torch, source_chroma, hue_weight);
	return mix(normal_torch, natural_source, clamp(RT_BLOCK_LIGHT_COLOR_STRENGTH, 0.0, 1.0));
}

// Saturation-corrected emitter colour. Very bright coloured light clips toward white after tonemapping, so the source colour is pushed
// away from grey first (luminance is preserved) and the final pass keeps the hue of over-exposed colours.
vec3 rtv_block_light_color(in vec3 emitter_pos, in uint packed_emitter)
{
    vec3 c = rtv_block_light_color_raw(emitter_pos, packed_emitter);
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    return max(mix(vec3(l), c, BLOCK_LIGHT_SATURATION), vec3(0.0));
}

vec3 rt_block_light(in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
{
    vec3 voxel_offset = vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition);
    vec3 ray_start = foot_pos + normal_face * 0.05;
    vec3 p_voxel = ray_start + voxel_offset;
    ivec3 emitter_shift = rtv_emitter_shift();
    ivec3 center_cell = ivec3(floor((p_voxel + vec3(emitter_shift)) / float(RTV_EMITTER_CELL)));

    // Two independent weighted reservoirs estimate the sum of all nearby emitters.
    // Each reservoir selects source i with probability weight_i / total_weight, so
    // total_weight * average(sample_radiance) is an unbiased estimate of their sum.
    float weight_sum = 0.0;
    vec3 chosen_pos_a = vec3(0.0);
    vec3 chosen_pos_b = vec3(0.0);
    uint chosen_emitter_a = 0u;
    uint chosen_emitter_b = 0u;
    bool found_a = false;
    bool found_b = false;

    ivec3 surface_voxel = ivec3(floor(foot_pos + voxel_offset - normal_face * 0.02));
    // Keep the wider 3-cell reach affordable: trim only the farthest cube corners,
    // while retaining the outer axial/diagonal cells needed for a 10-block radius.
    int search_limit_squared = RT_BLOCK_LIGHT_SEARCH * RT_BLOCK_LIGHT_SEARCH + RT_BLOCK_LIGHT_SEARCH;

    for (int dx = -RT_BLOCK_LIGHT_SEARCH; dx <= RT_BLOCK_LIGHT_SEARCH; dx++)
    for (int dy = -RT_BLOCK_LIGHT_SEARCH; dy <= RT_BLOCK_LIGHT_SEARCH; dy++)
    for (int dz = -RT_BLOCK_LIGHT_SEARCH; dz <= RT_BLOCK_LIGHT_SEARCH; dz++)
    {
        // optimisation: the light cannot reach the corners of the search cube, so only a sphere of cells is read (about half the work)
        if (dx * dx + dy * dy + dz * dz > search_limit_squared) continue;
        ivec3 cell = center_cell + ivec3(dx, dy, dz);
        if (any(lessThan(cell, ivec3(0))) || any(greaterThanEqual(cell, ivec3(RTV_EMITTER_GRID)))) continue;

        uint emitter_first = imageLoad(c_image_emitters, cell).r;
        if (emitter_first == 0u) continue;
        for (int slot = 0; slot < 2; slot++)
        {
        uint emitter = slot == 0 ? emitter_first : imageLoad(c_image_emitters, cell + ivec3(RTV_EMITTER_GRID, 0, 0)).r;
        if (emitter == 0u) continue;

        float level = float((emitter >> 28u) & 15u);
        ivec3 local = ivec3(int((emitter >> 4u) & 3u), int((emitter >> 2u) & 3u), int(emitter & 3u));
        vec3 emitter_pos = vec3(cell * RTV_EMITTER_CELL + local - emitter_shift) + 0.5;
        if (all(equal(surface_voxel, ivec3(floor(emitter_pos))))) continue;

        vec3 to_emitter = emitter_pos - p_voxel;
        float distance_to_light = max(length(to_emitter), 0.001);
        float n_dot_l = max(dot(normal_used, to_emitter / distance_to_light), 0.0);
        float weight = rtv_block_light_sample_weight(level, distance_to_light, n_dot_l);
        if (weight < 0.00025) continue;

        weight_sum += weight;
        float cell_noise = dot(vec3(cell), vec3(0.7548776662466927, 0.5698402909980532, 0.438289)) + float(slot) * 0.37;
        float random_a = fract(dither.x + dither.y * 0.61803398875 + cell_noise + dither.z * 0.271828);
        float random_b = fract(dither.z + dither.x * 0.41421356237 + cell_noise * 1.324717957 + 0.37);
        float replacement_probability = weight / max(weight_sum, 0.000001);

        if (random_a < replacement_probability)
        {
            chosen_pos_a = emitter_pos;
            chosen_emitter_a = emitter;
            found_a = true;
        }
        if (random_b < replacement_probability)
        {
            chosen_pos_b = emitter_pos;
            chosen_emitter_b = emitter;
            found_b = true;
        }
        } //slot
    }

    if ((!found_a && !found_b) || weight_sum <= 0.0) return vec3(0.0);

    vec3 sampled_radiance = vec3(0.0);
    float sample_count = 0.0;
    if (found_a)
    {
        vec3 visibility_a = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_a, dither.yzx - 0.5);
        vec3 color_a = rtv_block_light_color(chosen_pos_a, chosen_emitter_a);
        sampled_radiance += visibility_a * color_a * rtv_emitter_flicker(chosen_pos_a, float((chosen_emitter_a >> 28u) & 15u), color_a);
        sample_count += 1.0;
    }
    if (found_b)
    {
        vec3 jitter_b = fract(dither.zxy + vec3(0.37, 0.61, 0.83)) - 0.5;
        vec3 visibility_b = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_b, jitter_b);
        vec3 color_b = rtv_block_light_color(chosen_pos_b, chosen_emitter_b);
        sampled_radiance += visibility_b * color_b * rtv_emitter_flicker(chosen_pos_b, float((chosen_emitter_b >> 28u) & 15u), color_b);
        sample_count += 1.0;
    }

    return (sampled_radiance / max(sample_count, 1.0)) * weight_sum
        * (BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST * 0.32);
}

// A cheaper two-source estimate used only at the GI ray hit. This carries the mixed colour of nearby
// torches/lanterns into the next bounce while retaining visibility rays, so solid walls still block light.
vec3 rt_block_light_bounce(in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
{
    vec3 voxel_offset = vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition);
    vec3 ray_start = foot_pos + normal_face * 0.05;
    vec3 p_voxel = ray_start + voxel_offset;
    ivec3 emitter_shift = rtv_emitter_shift();
    ivec3 center_cell = ivec3(floor((p_voxel + vec3(emitter_shift)) / float(RTV_EMITTER_CELL)));
    ivec3 surface_voxel = ivec3(floor(foot_pos + voxel_offset - normal_face * 0.02));

    float weight_sum = 0.0;
    vec3 chosen_pos_a = vec3(0.0);
    vec3 chosen_pos_b = vec3(0.0);
    uint chosen_emitter_a = 0u;
    uint chosen_emitter_b = 0u;
    bool found_a = false;
    bool found_b = false;

    // GI-hit sampling is intentionally local and cheaper than primary surface lighting.
    for (int dx = -1; dx <= 1; dx++)
    for (int dy = -1; dy <= 1; dy++)
    for (int dz = -1; dz <= 1; dz++)
    {
        ivec3 cell = center_cell + ivec3(dx, dy, dz);
        if (any(lessThan(cell, ivec3(0))) || any(greaterThanEqual(cell, ivec3(RTV_EMITTER_GRID)))) continue;

        uint emitter_first = imageLoad(c_image_emitters, cell).r;
        if (emitter_first == 0u) continue;
        for (int slot = 0; slot < 2; slot++)
        {
        uint emitter = slot == 0 ? emitter_first : imageLoad(c_image_emitters, cell + ivec3(RTV_EMITTER_GRID, 0, 0)).r;
        if (emitter == 0u) continue;

        float level = float((emitter >> 28u) & 15u);
        ivec3 local = ivec3(int((emitter >> 4u) & 3u), int((emitter >> 2u) & 3u), int(emitter & 3u));
        vec3 emitter_pos = vec3(cell * RTV_EMITTER_CELL + local - emitter_shift) + 0.5;
        if (all(equal(surface_voxel, ivec3(floor(emitter_pos))))) continue;

        vec3 to_emitter = emitter_pos - p_voxel;
        float distance_to_light = max(length(to_emitter), 0.001);
        float n_dot_l = max(dot(normal_used, to_emitter / distance_to_light), 0.0);
        float weight = rtv_block_light_sample_weight(level, distance_to_light, n_dot_l);
        if (weight < 0.00025) continue;

        weight_sum += weight;
        float cell_noise = dot(vec3(cell), vec3(0.7548776662466927, 0.5698402909980532, 0.438289)) + float(slot) * 0.37;
        float random_a = fract(dither.x + dither.y * 0.61803398875 + cell_noise + dither.z * 0.271828);
        float random_b = fract(dither.z + dither.x * 0.41421356237 + cell_noise * 1.324717957 + 0.37);
        float replacement_probability = weight / max(weight_sum, 0.000001);

        if (random_a < replacement_probability)
        {
            chosen_pos_a = emitter_pos;
            chosen_emitter_a = emitter;
            found_a = true;
        }
        if (random_b < replacement_probability)
        {
            chosen_pos_b = emitter_pos;
            chosen_emitter_b = emitter;
            found_b = true;
        }
        } //slot
    }

    if ((!found_a && !found_b) || weight_sum <= 0.0) return vec3(0.0);

    vec3 sampled_radiance = vec3(0.0);
    float sample_count = 0.0;
    if (found_a)
    {
        vec3 visibility_a = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_a, dither.yzx - 0.5);
        vec3 color_a = rtv_block_light_color(chosen_pos_a, chosen_emitter_a);
        sampled_radiance += visibility_a * color_a * rtv_emitter_flicker(chosen_pos_a, float((chosen_emitter_a >> 28u) & 15u), color_a);
        sample_count += 1.0;
    }
    if (found_b)
    {
        vec3 jitter_b = fract(dither.zxy + vec3(0.37, 0.61, 0.83)) - 0.5;
        vec3 visibility_b = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_b, jitter_b);
        vec3 color_b = rtv_block_light_color(chosen_pos_b, chosen_emitter_b);
        sampled_radiance += visibility_b * color_b * rtv_emitter_flicker(chosen_pos_b, float((chosen_emitter_b >> 28u) & 15u), color_b);
        sample_count += 1.0;
    }

    return (sampled_radiance / max(sample_count, 1.0)) * weight_sum
        * (BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST * 0.32);
}
// ---------------------------------------------------------------------------------------------------------------------
// Dynamic held light: a torch / lantern / glowstone... in the main or off hand is a moving light source.
// It shares the same falloff, radius and source colours as placed lights. Its separate hand multiplier
// keeps the near-camera source readable; one visibility ray still makes it respect walls.
// ---------------------------------------------------------------------------------------------------------------------
#if HELD_LIGHT == 1
	uniform int heldBlockLightValue;  //main hand light level (0 = nothing that emits light)
	uniform int heldBlockLightValue2; //off hand light level
    uniform int heldItemId;
    uniform int heldItemId2;

	vec3 rtv_held_light_from(in vec3 light_pos, in float level, in vec3 source_color, in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
	{
		vec3 ray_start = foot_pos + normal_face * 0.05;
		vec3 to_light = light_pos - ray_start;
		float r2 = dot(to_light, to_light);
		float r = max(sqrt(r2), 0.001);
		vec3 dir = to_light / r;

		float ndl = max(dot(normal_used, dir), 0.0);
		if (ndl <= 0.0) return vec3(0.0);

		float w = rtv_block_light_sample_weight(level, r, ndl);
		if (w < 0.004) return vec3(0.0); //too dim to matter: skip the ray

		// small area light, jittered a little each frame so the shadow edge softens through temporal accumulation
		vec3 target = light_pos + (dither - 0.5) * (RT_BLOCK_LIGHT_SOFTNESS * 0.35);
		vec3 to_target = target - ray_start;
		float target_dist = max(length(to_target), 0.001);
		vec3 target_dir = to_target / target_dist;
		float visibility_limit = target_dist - 0.10;

		vec3 visibility = vec3(1.0);
		if (visibility_limit > 0.06)
		{
			Traced_shadow_ray light_ray = trace_light_ray(ray_start, target_dir, visibility_limit);
			visibility = light_ray.hit_something ? vec3(0.0) : clamp(light_ray.tint, vec3(0.0), vec3(1.0));
		}

		return visibility * max(mix(vec3(dot(source_color, vec3(0.2126, 0.7152, 0.0722))), source_color, BLOCK_LIGHT_SATURATION), vec3(0.0)) * w * (BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST * 0.20) * HELD_LIGHT_BRIGHTNESS;
	}

	vec3 rtv_held_light(in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
	{
		vec3 total = vec3(0.0);
		// hand positions in view space (x right, y up, -z forward), then moved into foot space with the same transform as every pixel
		if (heldBlockLightValue >= 3)
		{
			vec3 hand_pos = view_to_foot_space(vec3(0.32, -0.28, -0.45));
            vec3 hand_color = rtv_item_light_color(heldItemId);
            if (max(max(hand_color.r, hand_color.g), hand_color.b) < 0.01) hand_color = vec3(1.0, 0.76, 0.48);
			total += rtv_held_light_from(hand_pos, float(min(heldBlockLightValue, 15)), hand_color, foot_pos, normal_face, normal_used, dither.yzx);
		}
		if (heldBlockLightValue2 >= 3)
		{
			vec3 hand_pos2 = view_to_foot_space(vec3(-0.32, -0.28, -0.45));
            vec3 hand_color2 = rtv_item_light_color(heldItemId2);
            if (max(max(hand_color2.r, hand_color2.g), hand_color2.b) < 0.01) hand_color2 = vec3(1.0, 0.76, 0.48);
			total += rtv_held_light_from(hand_pos2, float(min(heldBlockLightValue2, 15)), hand_color2, foot_pos, normal_face, normal_used, fract(dither.zxy + vec3(0.37, 0.61, 0.83)));
		}
		return total;
	}
#endif

#endif
