//rt api selector

#define RT_API 6 //[1 2 3 4 5 6 7]
#define STUPID_RT_BIAS_IRIS_BUG 0.0 //[0.0 1.0 2.0 3.0]
#define RT_STEPS 80 //[20 30 40 50 60 70 80 90 100 120 130 140 150 200]

#if RT_API == 1
    #include "/stuff/rt/rt1.glsl"
#endif

#if RT_API == 2
    #include "/stuff/rt/rt2.glsl"
#endif

#if RT_API == 3
    #include "/stuff/rt/rt3.glsl"
#endif

#if RT_API == 4
    #include "/stuff/rt/rt4.glsl"
#endif

#if RT_API == 5
    #include "/stuff/rt/rt5.glsl"
#endif

#if RT_API == 6
    #include "/stuff/rt/rt6.glsl"
#endif

#if RT_API == 7
    #include "/stuff/rt/rt7.glsl"
#endif


