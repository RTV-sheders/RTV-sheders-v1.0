// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#if RT_API == 6

//DDA Trace with LOD bitmask and PBR Data reconstruction, 
	// Added Shadows to th trace result, shadowmap and rt
	// Added trace functions specifically for shadows


// Dependencies
	#include "/stuff/voxelizing/voxel_lods.glsl"


// Settings

    #define V_TRACE_BIAS 0.001


// Data Structures

// Set by the deferred pass: 1.0 while tracing a mirror-like reflection ray, 0.0 otherwise.
float rtv_hit_ambient_scale = 0.0;

struct Traced_ray{
    vec3 pos;
    bool hit_something;
    vec3 normals_face;
    vec3 dir;
    vec2 uvs;
    vec3 transmission_tint;
//temp
    bool hit_mob; // the ray ended on a mob/entity voxel (set while shading the hit)
    vec4 albedo;
    vec3 surface_albedo; // linear albedo before the traced hit is lit
    
};

struct Traced_shadow_ray{
    bool hit_something;
	vec3 tint;
};



// Functions


// Colour of light after passing through glass. Clear glass stays neutral; stained glass gives the light the colour of the glass
// (brightness removed, so a dark-red pane still gives clearly red light). A small smooth ripple keeps it from looking flat / printed.
vec3 rtv_glass_light_tint(in vec3 albedo, in vec3 p)
{
    float mx = max(max(albedo.r, albedo.g), albedo.b);
    float mn = min(min(albedo.r, albedo.g), albedo.b);
    float sat = (mx - mn) / max(mx, 0.001);
    vec3 hue = albedo / max(mx, 0.001);
    vec3 col = mix(vec3(1.0), hue, clamp(sat * GLASS_LIGHT_TINT, 0.0, 1.0));
    float ripple = sin(p.x * 2.3 + p.y * 1.7) * sin(p.z * 2.1 - p.y * 1.3) + 0.5 * sin((p.x + p.z) * 4.1);
    col *= 1.0 + 0.10 * GLASS_LIGHT_DISTORTION * ripple;
    return clamp(col, vec3(0.0), vec3(1.0)) * 0.94;
}

Traced_shadow_ray trace_shadow_ray(in vec3 pos, in vec3 dir)
{
	// A stripped down ray made for Shadows
	
    //initiate
    Traced_shadow_ray this_ray;
    this_ray.hit_something = false;
	this_ray.tint = vec3(1.0);
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
//	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
//            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
					//Slabs of LOD 
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
				//No LODs
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            
            #endif

        }//>in range
        
    }//>rt loop

	return this_ray;
}//> trace_shadow_ray




// A shadow ray that stops after max_dist, used to check that a light block is visible from a surface.
// It must stop short of the light block, because the light block itself is a solid voxel.
Traced_shadow_ray trace_light_ray(in vec3 pos, in vec3 dir, in float max_dist)
{
	// A stripped down ray made for Shadows
	
    //initiate
    Traced_shadow_ray this_ray;
    this_ray.hit_something = false;
	this_ray.tint = vec3(1.0);
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);
    vec3 start_pos = pos;

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
//	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
//            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);
        if (length(pos - start_pos) > max_dist) break; //reached the light block: nothing in between, so it is visible

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
					//Slabs of LOD 
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
				//No LODs
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            #endif
            




            // Direct block light should not treat every non-solid surface as a brick wall.
            // Glass, ice, water and partial/cutout geometry transmit part of the light;
            // fully solid voxels still block it. This avoids hard cut-offs behind leaves,
            // flowers, fences and transparent blocks without leaking through stone walls.
            #if VISUALIZED_DATA == 6
            if (this_ray.hit_something)
            {
                uint light_block_data = imageLoad(cimage1, voxel_pos).r;
                uint light_material = unpack_material_flag_from_voxel(light_block_data);
                vec3 transmission = vec3(1.0);
                bool pass_through = false;

                if (light_material == 1u) // water
                {
                    transmission = vec3(0.94, 0.975, 0.99);
                    pass_through = true;
                }
                else if (light_material == 3u) // clear glass
                {
                    vec3 glass_albedo = unpack_albedo_from_voxel(light_block_data);
                    transmission = rtv_glass_light_tint(glass_albedo, pos);
                    pass_through = true;
                }
                else if (light_material == 4u) // blue ice
                {
                    transmission = vec3(0.78, 0.86, 0.96);
                    pass_through = true;
                }
                else if (light_material == 5u) // mobs, dropped models and block-entity meshes
                {
                    // The player's own body (first person) must not dim the light that surrounds it, e.g. the held torch.
                    vec3 entity_foot = vec3(voxel_pos) + 0.5 - float(VOXEL_AREA / 2) - fract(cameraPosition);
                    bool entity_is_self = SELF_REFLECTION == 1 && abs(entity_foot.x) < 1.2 && abs(entity_foot.z) < 1.2 && entity_foot.y > -2.4 && entity_foot.y < 1.0;
                    // These are surface voxels sampled from the actual model vertices,
                    // not solid full-block cubes. A partial transmission makes their
                    // block-light shadow follow the body silhouette instead of forming
                    // a hard rectangular voxel shadow.
                    vec3 entity_albedo = unpack_albedo_from_voxel(light_block_data);
                    float entity_luma = dot(entity_albedo, vec3(0.2126, 0.7152, 0.0722));
                    float entity_opacity = mix(0.20, 0.34, 1.0 - clamp(entity_luma, 0.0, 1.0));
                    transmission = vec3(1.0 - entity_opacity);
                    transmission *= mix(vec3(1.0), max(entity_albedo, vec3(0.18)), 0.035);
                    if (entity_is_self) transmission = vec3(1.0);
                    pass_through = true;
                }
                else if (light_material == 6u) // foliage and other partial/cutout geometry
                {
                    vec3 partial_albedo = unpack_albedo_from_voxel(light_block_data);
                    float surface_luma = dot(partial_albedo, vec3(0.2126, 0.7152, 0.0722));
                    float transmission_strength = mix(0.60, 0.78, clamp(surface_luma, 0.0, 1.0)); //grass / flowers / leaves are mostly gaps
                    transmission = vec3(transmission_strength);
                    // A very subtle material tint keeps leaves natural without turning torch light green.
                    transmission *= mix(vec3(1.0), max(partial_albedo, vec3(0.18)), 0.08);
                    pass_through = true;
                }

                if (pass_through)
                {
                    this_ray.tint *= transmission;
                    this_ray.hit_something = max(max(this_ray.tint.r, this_ray.tint.g), this_ray.tint.b) < 0.035;
                }
            }
            #endif

        }//>in range
        
    }//>rt loop

	return this_ray;
}//> trace_shadow_ray




Traced_shadow_ray trace_shadow_ray_tinted(in vec3 pos, in vec3 dir)
{
	// A stripped down ray made for Shadows
	
    //initiate
    Traced_shadow_ray this_ray;
    this_ray.hit_something = false;
	this_ray.tint = vec3(1.0);
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
//	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
//            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
					//Slabs of LOD 
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
				//No LODs
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            
            #endif
            
            // Tint by glass color
            if(this_ray.hit_something)
            {
		 	        
		        #if VISUALIZED_DATA == 6
			        
			        //packed Voxel Scene Data 
			        //load data
			        uint packed_voxel = imageLoad(cimage1,voxel_pos ).r;
			        
			        //unpack Data
			        uint v_material_flag = unpack_material_flag_from_voxel(packed_voxel);

                    if(v_material_flag == 3u || v_material_flag == 4u)
                    {
                        vec3 v_rgb = unpack_albedo_from_voxel(packed_voxel);
                        if (v_material_flag == 3u)
                            this_ray.tint *= rtv_glass_light_tint(v_rgb, pos);
                        else
                            this_ray.tint *= mix(vec3(1.0), clamp(v_rgb, vec3(0.22), vec3(0.90)), 0.14) * 0.985;
                        this_ray.hit_something = false;
                    }
                #endif
            }//hit something

        }//>in range
        
    }//>rt loop

	return this_ray;
}//> trace_shadow_ray




Traced_shadow_ray trace_shadow_ray_tinted_cutout(in vec3 pos, in vec3 dir)
{
	// A stripped down ray made for Shadows
	
    //initiate
    Traced_shadow_ray this_ray;
    this_ray.hit_something = false;
	this_ray.tint = vec3(1.0);
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
//	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
//            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
					//Slabs of LOD 
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
				//No LODs
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            
            #endif
            
            // Tint by glass color 
            if(this_ray.hit_something)
            {
		 	        
		        #if VISUALIZED_DATA == 6
			        
                    /*cutout
			            //packed Voxel Scene Data 
			            //load data
			            uint packed_voxel = imageLoad(cimage1,voxel_pos ).r;
			            
			            //unpack Data
			            uint v_material_flag = unpack_material_flag_from_voxel(packed_voxel);
                
                        vec4 v_rgba = vec4(unpack_albedo_from_voxel(packed_voxel), 1.);
                        if(v_material_flag == 3u || v_rgba.a < .999 )
                            this_ray.hit_something = false;
                            if(this_ray.tint*= v_rgba.rgb;
                    */
                     #if TEXTURES_IN_RT > 0

                        //reconstruct UVs
			                //we have a 2x2x2 3d data structure of 8 cubes as big as the VOXEL_AREA, so we need to offset into the one we are using
			                ivec3 buffer_channel_offset = ivec3(0,0,VOXEL_AREA);
                            //position in the block is being used as the local texture coords
			                vec3 uv_pos = 1.-fract(pos);
			                //load the saved texture UVs from the voxel scene
			                vec4 uv_pos2 = unpack_uv_buffer( imageLoad(c_image4_voxel_scene, voxel_pos +buffer_channel_offset ).r );
                            //which local position coords to use depends on the face direction					
                            uv_pos.xy = v_normal.y != 0 ? uv_pos.xz : v_normal.z != 0 ? uv_pos.xy : uv_pos.zy;
                            //load texture from the bound atlas by reconstructing the UVs
			            
                        // Albedo
                            //load texture
                            vec4 v_texture = textureLod(atlas_a,uv_pos2.xy +uv_pos.xy*uv_pos2.ba,0);
                            if(v_texture.a<.999) this_ray.hit_something = false;
                            if(v_texture.a>0.001) this_ray.tint*=v_texture.rgb;
				    #endif
                    
                #endif
            }//hit something

        }//>in range
        
    }//>rt loop

	return this_ray;
}//> trace_shadow_ray









Traced_ray trace_ray(in vec3 pos, in vec3 dir, in bool transmit_ice)
{
    //initiate
    Traced_ray this_ray;
    this_ray.hit_mob = false;
    this_ray.hit_something = false;
    this_ray.surface_albedo = vec3(0.0);
    this_ray.transmission_tint = vec3(1.0);
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
					//Slabs of LOD 
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
				//No LODs
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            
            #endif

            // Glass and ice transmit secondary rays instead of behaving like opaque colored boxes.
            #if VISUALIZED_DATA == 6
            if (this_ray.hit_something)
            {
                uint current_voxel_data = imageLoad(cimage1, voxel_pos).r;
                uint current_material_flag = unpack_material_flag_from_voxel(current_voxel_data);
                if (current_material_flag == 3u || (current_material_flag == 4u && transmit_ice))
                {
                    vec3 layer_color = unpack_albedo_from_voxel(current_voxel_data);
                    if (current_material_flag == 3u)
                    {
                        // Clear / stained glass barely tints the view through it.
                        this_ray.transmission_tint *= mix(vec3(1.0), layer_color, 0.035);
                    }
                    else
                    {
                        // Ice gives transmitted light a restrained cool-blue absorption.
                        vec3 ice_filter = mix(vec3(1.0), clamp(layer_color, vec3(0.22), vec3(0.90)), 0.14);
                        this_ray.transmission_tint *= ice_filter * 0.985;
                    }
                    this_ray.hit_something = false;
                }
            }
            #endif

            // Cutout hits (seagrass, kelp, leaves, flowers, fences...): the voxel is a full cube, so without this test every plant seen in a
            // reflection / through water became a solid green block. The atlas alpha at the hit point now decides whether the ray is stopped.
            #if VISUALIZED_DATA == 6 && TEXTURES_IN_RT > 0 && RTV_CUTOUT_IN_RT == 1
            if (this_ray.hit_something)
            {
                uint cut_data = imageLoad(cimage1, voxel_pos).r;
                if (unpack_material_flag_from_voxel(cut_data) == 6u && unpack_pbr_from_voxel(cut_data).a <= 0.01)
                {
                    ivec3 cut_normal = last_dda_pos - ivec3(dda_pos);
                    vec3 cut_local = 1. - fract(pos);
                    cut_local.xy = cut_normal.y != 0 ? cut_local.xz : cut_normal.z != 0 ? cut_local.xy : cut_local.zy;
                    vec4 cut_uv = unpack_uv_buffer(imageLoad(c_image4_voxel_scene, voxel_pos + ivec3(0, 0, VOXEL_AREA)).r);
                    float cut_alpha = textureLod(atlas_a, cut_uv.xy + cut_local.xy * cut_uv.ba, 0).a;
                    if (cut_alpha < 0.5)
                    {
                        // Mostly-opaque textures (leaves) keep their hit: their holes show the dark inside of the foliage instead of a bright sky
                        // seen through one cube layer (that was the white-blue rim around reflected trees and leaf blocks).
                        // Mostly-transparent textures (seagrass, kelp, grass, flowers) let the ray continue.
                        float cut_mip = log2(max(cut_uv.b * float(textureSize(atlas_a, 0).x), 1.0));
                        float cut_mean_alpha = textureLod(atlas_a, cut_uv.xy + cut_uv.ba * 0.5, cut_mip).a;
                        if (cut_mean_alpha < 0.62) this_ray.hit_something = false;
                    }
                }
            }
            #endif

        }//>in range
        
    }//>rt loop






    if(this_ray.hit_something)
    {
		//normals
				ivec3 v_normal = last_dda_pos-ivec3(dda_pos);
				this_ray.normals_face = vec3(v_normal);
				
		#if VISUALIZED_DATA == 6
			
			//packed Voxel Scene Data 
				//load data
				uint packed_voxel = imageLoad(cimage1,voxel_pos ).r;
				
				//unpack Data
				vec2 v_lightmap = unpack_lightmap_from_voxel(packed_voxel);
				vec4 v_specular = unpack_pbr_from_voxel(packed_voxel);
				vec4 v_rgba = vec4(unpack_albedo_from_voxel(packed_voxel), 1.);
				uint v_material_flag = unpack_material_flag_from_voxel(packed_voxel);
				
				float v_sss = 0.;
			
			
			#if TEXTURES_IN_RT == 0
				this_ray.albedo.rgb = v_rgba.rgb;
			#endif
        #else
			//> not densely packed voxel Data
			
			 //approximated scene 
			 this_ray.albedo = unpackUnorm4x8( imageLoad(cimage1,voxel_pos ).r );
                
		#endif
		
        //< Textures
		vec3 v_normals_used;
		this_ray.hit_mob = (v_material_flag == 5u);
		if(v_material_flag==5u || (v_material_flag==6u && v_specular.a > 0.01) )
		{//no textures on entities, since they don't use the main atlas
			v_normals_used = this_ray.normals_face;
			this_ray.albedo = v_rgba;
		}else{
        #if TEXTURES_IN_RT > 0

            //reconstruct UVs
			    //we have a 2x2x2 3d data structure of 8 cubes as big as the VOXEL_AREA, so we need to offset into the one we are using
			    ivec3 buffer_channel_offset = ivec3(0,0,VOXEL_AREA);
                //position in the block is being used as the local texture coords
			    vec3 uv_pos = 1.-fract(pos);
			    //load the saved texture UVs from the voxel scene
			    vec4 uv_pos2 = unpack_uv_buffer( imageLoad(c_image4_voxel_scene, voxel_pos +buffer_channel_offset ).r );
                //which local position coords to use depends on the face direction					
                uv_pos.xy = v_normal.y != 0 ? uv_pos.xz : v_normal.z != 0 ? uv_pos.xy : uv_pos.zy;
                //load texture from the bound atlas by reconstructing the UVs
			
            // Albedo
                //load texture
                vec4 v_texture = textureLod(atlas_a,uv_pos2.xy +uv_pos.xy*uv_pos2.ba,0);
				    
			    //gl color
			    vec3 glcolor = unpack_uv_buffer_channel_3( imageLoad(c_image4_voxel_scene, voxel_pos 
                    +ivec3(0,VOXEL_AREA,VOXEL_AREA) //offset for gl color in the 2x2x2 Voxel Scene
                     ).r );
			    v_texture.rgb = v_texture.rgb * glcolor; 
                
                //set
			    this_ray.albedo = v_texture;
            
            // Normals
            #if TEXTURES_IN_RT >= 3
                //load texture
                vec4 v_texture_n = textureLod(atlas_n,uv_pos2.xy +uv_pos.xy*uv_pos2.ba,0);

                //unpack labpbr standard
                v_texture_n = v_texture_n*2.-1.;
                //float v_ao = v_texture_n.b;
                //float v_height_map = v_texture_n.a;
				v_texture_n.z = sqrt(1.0-dot(v_texture_n.xy, v_texture_n.xy));
				v_texture_n.xyz = normalize(v_texture_n.xyz);//

                //construct and use a TBN to rotate the texture alignment to the face in the world
                vec3 v_tang = v_normal.y != 0 ? vec3(-1.,0.,0.) : v_normal.z != 0 ? vec3(-1.,0.,0.) : vec3(0.,0.,-1.);
				vec3 v_bitan = v_normal.y != 0 ? vec3(0.,0.,-1.) : v_normal.z != 0 ? vec3(0.,-1.,0.) : vec3(0.,-1.,0.);
				
                mat3 tbn_matrix = mat3(v_tang.xyz, v_bitan.xyz, this_ray.normals_face.xyz);
				
                v_normals_used = normalize(tbn_matrix*v_texture_n.xyz);

            #else
                v_normals_used = this_ray.normals_face;
            #endif

            //Specular
            #if TEXTURES_IN_RT >= 5
                 //load texture
                vec4 v_texture_s = textureLod(atlas_s,uv_pos2.xy +uv_pos.xy*uv_pos2.ba,0);
                v_texture_s.a = fract(v_texture_s.a);//unpack labpbr emission
                //use texture
                v_specular = v_texture_s;
               
            #endif

        #else
            v_normals_used = this_ray.normals_face;
		#endif		
		}
		
		
        #if VISUALIZED_DATA == 6 && TEXTURES_IN_RT > 0
            if (v_material_flag == 4u)
                this_ray.albedo.rgb = mix(this_ray.albedo.rgb, vec3(0.015, 0.070, 0.18), 0.48);
        #endif

		//prep albedo for lighting calculations
		this_ray.albedo.rgb = srgb_to_linear(this_ray.albedo.rgb);
		this_ray.surface_albedo = this_ray.albedo.rgb;


		// Apply Lighting
		#if VISUALIZED_DATA == 6
			// Shadows
				//shadow ray
				#if SHADOWS_IN_VOXEL_SCENE == 0
					float sun_lighting = dot(v_normals_used,Sun_or_moon_dir_world);
					vec3 sunlight_color_here = vec3(sun_lighting);
				#endif

                #if SHADOWS_IN_VOXEL_SCENE == 1
					vec3 sunlight_color_here;
                    float sun_lighting = dot(this_ray.normals_face,Sun_or_moon_dir_world);
					if(sun_lighting>0.01)
					{
						sun_lighting = dot(v_normals_used,Sun_or_moon_dir_world);
						if(sun_lighting>0.01)
						{
							Traced_shadow_ray shadow_ray = 
                            #if COLORED_RT_SHADOWS == 1
                                #if RT_SHADOW_TEXTURES == 1
                                    trace_shadow_ray_tinted_cutout( 
                                #else
                                    trace_shadow_ray_tinted( 
                                #endif
                            #else
                                trace_shadow_ray(
                            #endif

								pos-(VOXEL_AREA/2+fract(cameraPosition))+Sun_or_moon_dir_world*.001,
								Sun_or_moon_dir_world);
							sun_lighting = (shadow_ray.hit_something) ? 0.:sun_lighting;
							sunlight_color_here = vec3(max(0.,sun_lighting))*shadow_ray.tint;
						}
					}
					if(sun_lighting<=0.01) sunlight_color_here=vec3(0.);
                #endif
				#if SHADOWS_IN_VOXEL_SCENE == 2
				//shadowmap
					vec3 sunlight_color_here;
					float sun_lighting = dot(this_ray.normals_face,Sun_or_moon_dir_world);
					if(sun_lighting>0.01)
					{
						sun_lighting = dot(v_normals_used,Sun_or_moon_dir_world);
						if(sun_lighting>0.01)
						{
							sunlight_color_here = get_shadows_at_foot_pos(
							pos-(VOXEL_AREA/2+fract(cameraPosition))
							,this_ray.normals_face, Dither_offset, v_sss,
							sun_lighting) * sun_lighting; //visibility * N.L
						}
					}
					if(sun_lighting<=0.01) sunlight_color_here=vec3(0.);

					
				#endif
						
            vec3 emissive_radiance = rtv_soft_compress_radiance(
                v_specular.a * this_ray.albedo.rgb * BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST);
			vec3 lighting = 
				sunlight_color_here * SUN_BRIGHTNESS * SUN_SURFACE_STRENGTH * rtv_sunlight_factor() * rtv_sun_color() * smoothstep(0.02, 0.25, v_lightmap.y) //daylight / moonlight, none in caves / covered areas
                + emissive_radiance // hue-preserved emissive radiance
				#if VANILLA_BLOCK_LIGHT_IN_RT == 1
					+ v_lightmap.x * vec3(1.,.9,.5) //block light
				#endif
				#if VANILLA_SKY_LIGHT_IN_RT == 1
					+ (skyColor) * v_lightmap.y * ( 
						dot(v_normals_used,vec3(0.,1.,0.))
						*.5 + .5 ) 
						*SUN_BRIGHTNESS*SKY_BRIGHTNESS_IN_RT*rtv_sky_illumination_factor()
						//sky light
				#endif
					// Low-energy sky bounce: enclosed cave hits get almost no sky fill, while exposed
					// secondary-ray surfaces still receive soft ambient from openings and skylights.
					+ max(skyColor, vec3(0.012, 0.016, 0.024))
						* (SUN_BRIGHTNESS * SKY_BRIGHTNESS_IN_RT * rtv_sky_illumination_factor())
						* GI_SKY_BOUNCE_STRENGTH
						* mix(0.015, 1.0, smoothstep(0.02, 0.48, v_lightmap.y))
						* (0.78 + 0.22 * max(v_normals_used.y, 0.0))
					// Reflections only: a faint cool ambient so a metal / ice / glass surface can still show the shapes around it in the dark.
					+ vec3(0.80, 0.88, 1.00) * (REFLECTION_AMBIENT * rtv_hit_ambient_scale) * (0.6 + 0.4 * max(v_normals_used.y, 0.0))
			
			;
			
			this_ray.albedo.rgb = this_ray.albedo.rgb*lighting;
			
			

		#endif
		
        //> Textures
    }
    
	//add sky for rays that didn't hit anything
		this_ray.albedo.rgb = (this_ray.hit_something) ? 
				this_ray.albedo.rgb 
				:  (dot(Sun_or_moon_dir_world,dir) > 1.- SUN_WIDTH*.00025 ? SUN_BRIGHTNESS * rtv_sunlight_factor() * rtv_sun_color() : SUN_BRIGHTNESS*SKY_BRIGHTNESS_IN_RT*rtv_sky_illumination_factor()*(skyColor));
        this_ray.albedo.rgb *= this_ray.transmission_tint;
					
    ///debug area
    
    //return to player_space
    pos-=VOXEL_AREA/2+fract(cameraPosition);

    //output result
    this_ray.pos = pos;
    this_ray.dir = dir;
    return this_ray;
}

// Default secondary rays can reflect from ice; primary refraction opts into ice transmission.
Traced_ray trace_ray(in vec3 pos, in vec3 dir)
{
    return trace_ray(pos, dir, false);
}
#endif
