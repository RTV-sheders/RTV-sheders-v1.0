/*
	This code is from the VOXELIZING TUTORIAL by timetravelbeard
		learn more at the links below:
			https://www.patreon.com/timetravelbeard
			https://youtube.com/@timetravelbeard3588
			https://discord.gg/S6F4r6K5yU 
			
		if you use this code as is, please leave this header. feel free to use this code in any shaders.
*/
	
	//positions
	vec3 shadow_view_pos = vec4(gl_ModelViewMatrix * gl_Vertex).xyz;
	vec3 foot_pos = (shadowModelViewInverse * vec4( shadow_view_pos ,1.) ).xyz;
	vec3 world_pos = foot_pos + cameraPosition;


	//voxel map position
	#define VOXEL_RADIUS (VOXEL_AREA/2)
    
    bool rtv_partial_geometry = false;
    bool rtv_write_all_vertices = false;
    vec3 block_centered_relative_pos;
    #if IS_AN_ENTITY == 1
        // Midblock is not valid for mobs, dropped models or block-entity meshes.
        // Preserve each mesh vertex instead of collapsing the whole model to a block centre.
        block_centered_relative_pos = foot_pos + fract(cameraPosition);
        rtv_write_all_vertices = true;
    #else
        // Full cubes retain their single block-centre voxel (fast and watertight).
        // Stairs, fences, furniture and other non-cubic models use their real vertex positions.
        rtv_partial_geometry = abs(length(at_midBlock.xyz) - 55.0) > 0.5;
        block_centered_relative_pos = foot_pos + fract(cameraPosition);
        if (!rtv_partial_geometry)
            block_centered_relative_pos += at_midBlock.xyz / 64.0;
        rtv_write_all_vertices = rtv_partial_geometry;
    #endif

    ivec3 voxel_pos = ivec3(floor(block_centered_relative_pos + VOXEL_RADIUS));
    float rtv_voxel_alpha = textureLod(gtexture, texcoord, 0.0).a * glcolor.a;
    bool rtv_vertex_sample = rtv_write_all_vertices || (mod(gl_VertexID, 4) == 0);


	//write voxel data
	if(
		#if IS_AN_ENTITY == 1
			(SELF_REFLECTION == 1 || entityId != 100)
		#else
			(SELF_REFLECTION == 1 || !(renderStage == MC_RENDER_STAGE_ENTITIES && entityId == 100))
		#endif
        && rtv_vertex_sample // full cubes: one representative vertex; meshes: all face vertices
        && (!rtv_write_all_vertices || rtv_voxel_alpha > 0.08) // cutout test only on mesh-sampled geometry
		&& clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos //and in voxel range
	) //for one vertex per face, write if in range
	{
		//pick data to send
		
		#if VISUALIZED_DATA == 0
			//visualize color average
			vec4 voxel_data =	vec4(textureLod(gtexture, texcoord,log2(float(textureSize(gtexture, 0).x))).rgb* glcolor.rgb,1.);
		#endif
		#if VISUALIZED_DATA == 1
			//visualize position
			vec4 voxel_data = vec4(fract((block_centered_relative_pos.xyz+floor(cameraPosition))*.05),1.);
		#endif
		#if VISUALIZED_DATA == 2
			//visualize color of one pixel
			vec4 voxel_data =	vec4(textureLod(gtexture, texcoord,0).rgb* glcolor.rgb,1.);
		#endif
		#if VISUALIZED_DATA == 3
			//light value
			vec4 voxel_data =	vec4(at_midBlock.w);
		#endif
		#if VISUALIZED_DATA == 4
			//certain block by id
			vec4 voxel_data =	mc_Entity.x == 10000.? vec4(0.,1.,0.,1.) : mc_Entity.x == 10001.? vec4(0.5,0.5,0.,1.) : vec4(0.2);
		#endif
		#if VISUALIZED_DATA == 5
			//visualize color average
			vec4 voxel_data =	vec4(textureLod(gtexture, texcoord,log2(float(textureSize(gtexture, 0).x))).rgb* glcolor.rgb,1.);
            //lighting
            voxel_data.rgb = clamp( voxel_data.rgb * (max(at_midBlock.w,lmcoord.x)*vec3(1.,.9,.7)+mix(skyColor,vec3(1.),min(1.,skyColor.r*2.)) *lmcoord.y), 0.,1.);
		#endif
		
		#if VISUALIZED_DATA == 6
			uint integerValue = pack_voxel_with_dense_PBR();
		#endif
		

		
		//pack data
		#if VISUALIZED_DATA < 6
			//visialize player position
			if(frameTimeCounter < 1. && distance(vec3(voxel_pos),vec3(VOXEL_RADIUS))< 3.)
			{
				voxel_data = vec4(0.,0.,1.,1.);
			}
		
		    uint integerValue = packUnorm4x8( voxel_data );
		#endif
		
		//write to 3d image	 
		//          //imageStore(  //imageAtomicMax(   are some options for writing, look up on khronos.org (opengl documentation)
		imageAtomicMax( cimage1, voxel_pos, integerValue );	
			
		#if VOXEL_LODS > 0
            write_to_voxel_lod(voxel_pos);
        #endif
			
		// World and dropped-item emitters share the same ray-traced colored-light path.
		#if RT_BLOCK_LIGHT_NEE == 1
            #if IS_AN_ENTITY == 1
                uint rtv_light_level = uint(rtv_dropped_item_light_level(currentRenderedItemId));
                vec3 rtv_item_color = rtv_item_light_color(currentRenderedItemId);
            #else
                // Some block models do not provide a stable at_midBlock.w value in
                // the shadow pass. Use known vanilla emission as a fallback while
                // preserving dynamic/state-dependent light levels when available.
                float rtv_mapped_level = rtv_mapped_block_light_level(mc_Entity.x);
                uint rtv_light_level = uint(clamp(max(at_midBlock.w, rtv_mapped_level) + 0.5, 0., 15.));
                vec3 rtv_item_color = vec3(0.0);
            #endif
			// Keep one light-emitter sample per quad; mesh surface voxelization above may write all vertices.
			if (rtv_light_level >= 3u && mod(gl_VertexID, 4) == 0)
			{
				ivec3 rtv_shifted = voxel_pos + rtv_emitter_shift(); //world-aligned cells, see emitters.glsl
				ivec3 rtv_cell = rtv_shifted / RTV_EMITTER_CELL;
				ivec3 rtv_local = rtv_shifted - rtv_cell * RTV_EMITTER_CELL;
				// Keep the light level in the highest four bits so imageAtomicMax always
                // selects the brighter source first, regardless of its colour.
                uint rtv_emitter = (rtv_light_level << 28u) | (uint(rtv_local.x) << 4u) | (uint(rtv_local.y) << 2u) | uint(rtv_local.z);
                #if IS_AN_ENTITY == 1
                    // Bits 6-20 store a compact 5-bit RGB spectrum; bit 21 marks an item-colour override.
                    uvec3 rtv_rgb5 = uvec3(round(clamp(rtv_item_color, 0.0, 1.0) * 31.0));
                    rtv_emitter |= (rtv_rgb5.r << 6u) | (rtv_rgb5.g << 11u) | (rtv_rgb5.b << 16u) | (1u << 21u);
                #else
                    // Bit 22 marks lava; bits 23..27 identify known placed light types.
                    // The type tag survives atlas mip/texture averaging and keeps each
                    // source's colour stable in direct light and GI bounce.
                    if (abs(mc_Entity.x - 14.0) < 0.5) rtv_emitter |= (1u << 22u);
                    if (mc_Entity.x >= 15.0 && mc_Entity.x <= 40.0)
                    {
                        uint rtv_source_type = uint(clamp(mc_Entity.x - 14.0, 0.0, 31.0));
                        rtv_emitter |= (rtv_source_type & 31u) << 23u;
                    }
                #endif
				if (all(lessThan(rtv_cell, ivec3(RTV_EMITTER_GRID))))
				{
					// Two slots per cell: A = strongest, B = runner-up (stored at x + GRID). With one slot, two light blocks closer than ~3 blocks
					// shared a cell and only one of them existed: the other one was dark until the first was broken.
					uint rtv_old = imageAtomicMax(c_image_emitters, rtv_cell, rtv_emitter);
					if (rtv_old != rtv_emitter)
					{
						uint rtv_loser = min(rtv_old, rtv_emitter);
						if (rtv_loser != 0u)
							imageAtomicMax(c_image_emitters, rtv_cell + ivec3(RTV_EMITTER_GRID, 0, 0), rtv_loser);
					}
				}
			}
		#endif
				
		#if TEXTURES_IN_RT > 0
			deconstruct_and_localize_uvs();
			
			ivec3 buffer_channel_offset = ivec3(0,0,VOXEL_AREA);//texture uvs
			vec3 normals_face = vec3(0.);
			integerValue =  pack_uv_buffer(
				#if USE_VX_UV_BUFFER == 1
					vec4(quad_center,vlocal_uv_components.ba)
				#else
					vlocal_uv_components
				#endif
				
				, normals_face.xyz);
				
			//write UVs			
			imageAtomicMax( c_image4_voxel_scene, voxel_pos+buffer_channel_offset, integerValue );	
			
			//Write glcolor
			integerValue = pack_uv_buffer_channel_3(gl_Color.rgb);
			imageAtomicMax( c_image4_voxel_scene, voxel_pos
				+ivec3(0,VOXEL_AREA,VOXEL_AREA)//glcolor (channel 3)
				, integerValue );	
		#endif	
				
	}//> voxelizing this vertex
