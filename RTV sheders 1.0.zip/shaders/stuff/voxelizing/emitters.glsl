// Emitter grid: one compact 3D image that remembers, for every 3 x 3 x 3 block cell, the brightest light block or
// explicitly mapped glowing item inside it. It is written by the shadow pass together with the voxel scene.
//   bits 0-5: local xyz position; bits 6-20: optional item RGB; bit 21: item-colour flag; bit 22: lava hue tag;
//   bits 28-31: light level. Other block emitters keep their colour in the voxel scene.
// Dropped glowing items carry a compact source-colour override while brightness stays the priority key.
#ifndef RTV_EMITTERS_INCLUDED
#define RTV_EMITTERS_INCLUDED 1
#if RT_BLOCK_LIGHT_NEE == 1
    layout (r32ui) uniform uimage3D c_image_emitters;
    #define RTV_EMITTER_CELL 3
    #define RTV_EMITTER_GRID ((VOXEL_AREA + RTV_EMITTER_CELL - 1) / RTV_EMITTER_CELL)

    // Iris item.properties IDs used by RTV for luminous items. These are intentionally
    // pack-local IDs and do not collide with Minecraft's registry IDs.
    #define RTV_ITEM_TORCH             60001
    #define RTV_ITEM_LANTERN           60002
    #define RTV_ITEM_GLOWSTONE         60003
    #define RTV_ITEM_SHROOMLIGHT       60004
    #define RTV_ITEM_CAMPFIRE          60005
    #define RTV_ITEM_SOUL_TORCH        60006
    #define RTV_ITEM_SOUL_LANTERN      60007
    #define RTV_ITEM_REDSTONE_TORCH    60008
    #define RTV_ITEM_SEA_LANTERN       60009
    #define RTV_ITEM_END_ROD           60010
    #define RTV_ITEM_OCHRE_FROGLIGHT   60011
    #define RTV_ITEM_VERDANT_FROGLIGHT 60012
    #define RTV_ITEM_PEARL_FROGLIGHT   60013
    #define RTV_ITEM_LAVA_BUCKET       60014
    #define RTV_ITEM_CANDLE            60015
    #define RTV_ITEM_CRYING_OBSIDIAN   60016
    #define RTV_ITEM_AMETHYST          60017
    #define RTV_ITEM_SCULK_CATALYST    60018
    #define RTV_ITEM_BEACON            60019
    #define RTV_ITEM_CONDUIT           60020
    #define RTV_ITEM_RESPAWN_ANCHOR    60021
    #define RTV_ITEM_MAGMA             60022
    #define RTV_ITEM_GLOW_LICHEN       60023
    #define RTV_ITEM_SEA_PICKLE        60024
    #define RTV_ITEM_ENCHANTING_TABLE  60025

    // Stable block-emitter fallback levels. Iris' at_midBlock.w is still used when
    // available (important for state-dependent sources such as candles/sea pickles),
    // but explicit vanilla levels keep placed lights working on geometry where that
    // attribute is missing or inconsistent.
    float rtv_mapped_block_light_level(in float block_id)
    {
        if (abs(block_id - 14.0) < 0.5) return 15.0; // lava
        if (abs(block_id - 15.0) < 0.5) return 14.0; // torch
        if (abs(block_id - 16.0) < 0.5) return 15.0; // lantern
        if (abs(block_id - 17.0) < 0.5) return 10.0; // soul torch
        if (abs(block_id - 18.0) < 0.5) return 10.0; // soul lantern
        if (abs(block_id - 19.0) < 0.5) return 7.0;  // redstone torch
        if (abs(block_id - 20.0) < 0.5) return 15.0; // glowstone
        if (abs(block_id - 21.0) < 0.5) return 15.0; // sea lantern
        if (abs(block_id - 22.0) < 0.5) return 15.0; // shroomlight
        if (abs(block_id - 23.0) < 0.5) return 15.0; // ochre froglight
        if (abs(block_id - 24.0) < 0.5) return 15.0; // verdant froglight
        if (abs(block_id - 25.0) < 0.5) return 15.0; // pearlescent froglight
        if (abs(block_id - 26.0) < 0.5) return 14.0; // end rod
        if (abs(block_id - 27.0) < 0.5) return 15.0; // campfire
        if (abs(block_id - 28.0) < 0.5) return 10.0; // soul campfire
        if (abs(block_id - 30.0) < 0.5) return 3.0;  // magma block
        if (abs(block_id - 33.0) < 0.5) return 7.0;  // glow lichen
        if (abs(block_id - 36.0) < 0.5) return 15.0; // conduit
        if (abs(block_id - 37.0) < 0.5) return 15.0; // beacon
        return 0.0; // state-dependent or modded emitters use at_midBlock.w
    }

    // Source type is packed in bits 23..27 of the emitter uint. The colour is
    // assigned by block family, not by a blurred/mipped atlas sample.
    vec3 rtv_mapped_block_light_color(in uint source_type)
    {
        if (source_type == 1u)  return vec3(1.00, 0.76, 0.48); // torch
        if (source_type == 2u)  return vec3(1.00, 0.68, 0.39); // lantern
        if (source_type == 3u)  return vec3(0.18, 0.48, 1.00); // soul torch
        if (source_type == 4u)  return vec3(0.28, 0.60, 1.00); // soul lantern
        if (source_type == 5u)  return vec3(1.00, 0.035, 0.020); // redstone torch
        if (source_type == 6u)  return vec3(1.00, 0.82, 0.55); // glowstone
        if (source_type == 7u)  return vec3(0.48, 0.80, 1.00); // sea lantern
        if (source_type == 8u)  return vec3(1.00, 0.46, 0.22); // shroomlight
        if (source_type == 9u)  return vec3(1.00, 0.72, 0.32); // ochre froglight
        if (source_type == 10u) return vec3(0.38, 1.00, 0.30); // verdant froglight
        if (source_type == 11u) return vec3(0.76, 0.48, 1.00); // pearlescent froglight
        if (source_type == 12u) return vec3(0.80, 0.88, 1.00); // end rod
        if (source_type == 13u) return vec3(1.00, 0.40, 0.13); // campfire
        if (source_type == 14u) return vec3(0.18, 0.46, 1.00); // soul campfire
        if (source_type == 15u) return vec3(1.00, 0.72, 0.38); // candle
        if (source_type == 16u) return vec3(1.00, 0.35, 0.10); // magma
        if (source_type == 17u) return vec3(1.00, 0.54, 0.22); // redstone lamp
        if (source_type == 18u) return vec3(0.70, 0.26, 1.00); // respawn anchor
        if (source_type == 19u) return vec3(0.52, 1.00, 0.58); // glow lichen
        if (source_type == 20u) return vec3(0.35, 1.00, 0.72); // sea pickle
        if (source_type == 21u) return vec3(0.12, 0.72, 0.92); // sculk catalyst
        if (source_type == 22u) return vec3(0.42, 0.88, 1.00); // conduit
        if (source_type == 23u) return vec3(0.68, 0.92, 1.00); // beacon
        if (source_type == 24u) return vec3(0.70, 0.44, 1.00); // amethyst
        if (source_type == 25u) return vec3(1.00, 0.76, 0.30); // cave vines / glow berries
        return vec3(0.0);
    }

    int rtv_dropped_item_light_level(in int item_id)
    {
        if (item_id == RTV_ITEM_TORCH) return 14;
        if (item_id == RTV_ITEM_LANTERN) return 15;
        if (item_id == RTV_ITEM_GLOWSTONE) return 15;
        if (item_id == RTV_ITEM_SHROOMLIGHT) return 15;
        if (item_id == RTV_ITEM_CAMPFIRE) return 15;
        if (item_id == RTV_ITEM_SOUL_TORCH) return 10;
        if (item_id == RTV_ITEM_SOUL_LANTERN) return 10;
        if (item_id == RTV_ITEM_REDSTONE_TORCH) return 7;
        if (item_id == RTV_ITEM_SEA_LANTERN) return 15;
        if (item_id == RTV_ITEM_END_ROD) return 14;
        if (item_id == RTV_ITEM_OCHRE_FROGLIGHT) return 15;
        if (item_id == RTV_ITEM_VERDANT_FROGLIGHT) return 15;
        if (item_id == RTV_ITEM_PEARL_FROGLIGHT) return 15;
        if (item_id == RTV_ITEM_LAVA_BUCKET) return 15;
        if (item_id == RTV_ITEM_CANDLE) return 3;
        if (item_id == RTV_ITEM_CRYING_OBSIDIAN) return 10;
        if (item_id == RTV_ITEM_AMETHYST) return 5;
        if (item_id == RTV_ITEM_SCULK_CATALYST) return 6;
        if (item_id == RTV_ITEM_BEACON) return 15;
        if (item_id == RTV_ITEM_CONDUIT) return 15;
        if (item_id == RTV_ITEM_RESPAWN_ANCHOR) return 15;
        if (item_id == RTV_ITEM_MAGMA) return 3;
        if (item_id == RTV_ITEM_GLOW_LICHEN) return 7;
        if (item_id == RTV_ITEM_SEA_PICKLE) return 6;
        if (item_id == RTV_ITEM_ENCHANTING_TABLE) return 7;
        return 0;
    }

    vec3 rtv_item_light_color(in int item_id)
    {
        if (item_id == RTV_ITEM_TORCH) return vec3(1.00, 0.76, 0.48);
        if (item_id == RTV_ITEM_LANTERN) return vec3(1.00, 0.68, 0.39);
        if (item_id == RTV_ITEM_GLOWSTONE) return vec3(1.00, 0.82, 0.55);
        if (item_id == RTV_ITEM_SHROOMLIGHT) return vec3(1.00, 0.46, 0.22);
        if (item_id == RTV_ITEM_CAMPFIRE) return vec3(1.00, 0.40, 0.13);
        if (item_id == RTV_ITEM_SOUL_TORCH) return vec3(0.18, 0.48, 1.00);
        if (item_id == RTV_ITEM_SOUL_LANTERN) return vec3(0.28, 0.60, 1.00);
        if (item_id == RTV_ITEM_REDSTONE_TORCH) return vec3(1.00, 0.035, 0.020);
        if (item_id == RTV_ITEM_SEA_LANTERN) return vec3(0.48, 0.80, 1.00);
        if (item_id == RTV_ITEM_END_ROD) return vec3(0.82, 0.88, 1.00);
        if (item_id == RTV_ITEM_OCHRE_FROGLIGHT) return vec3(1.00, 0.74, 0.32);
        if (item_id == RTV_ITEM_VERDANT_FROGLIGHT) return vec3(0.38, 1.00, 0.30);
        if (item_id == RTV_ITEM_LAVA_BUCKET) return vec3(1.00, 0.38, 0.08);
        if (item_id == RTV_ITEM_CANDLE) return vec3(1.00, 0.72, 0.38);
        if (item_id == RTV_ITEM_CRYING_OBSIDIAN) return vec3(0.62, 0.20, 1.00);
        if (item_id == RTV_ITEM_AMETHYST) return vec3(0.70, 0.40, 1.00);
        if (item_id == RTV_ITEM_SCULK_CATALYST) return vec3(0.10, 0.75, 0.95);
        if (item_id == RTV_ITEM_BEACON) return vec3(0.70, 0.92, 1.00);
        if (item_id == RTV_ITEM_CONDUIT) return vec3(0.45, 0.90, 1.00);
        if (item_id == RTV_ITEM_RESPAWN_ANCHOR) return vec3(0.75, 0.30, 1.00);
        if (item_id == RTV_ITEM_MAGMA) return vec3(1.00, 0.35, 0.10);
        if (item_id == RTV_ITEM_GLOW_LICHEN) return vec3(0.55, 1.00, 0.55);
        if (item_id == RTV_ITEM_SEA_PICKLE) return vec3(0.40, 1.00, 0.75);
        if (item_id == RTV_ITEM_ENCHANTING_TABLE) return vec3(0.50, 0.70, 1.00);
        if (item_id == RTV_ITEM_PEARL_FROGLIGHT) return vec3(0.76, 0.50, 1.00);
        return vec3(0.0);
    }

    // The voxel volume moves with the camera (it is re-centred every time you cross a block border). If the 3x3x3 cells moved with it,
    // the single emitter stored per cell would change whenever you walked, and lights would pop on and off. This shift keeps the cell
    // borders locked to the world (multiples of 3 blocks), so the same emitter always wins in the same cell.
    // Cells are addressed with (voxel + shift) / 3, so the same emitters stay stable as the camera moves.
    ivec3 rtv_emitter_shift()
    {
        return ivec3(mod(floor(cameraPosition), vec3(float(RTV_EMITTER_CELL))));
    }
#endif
#endif
