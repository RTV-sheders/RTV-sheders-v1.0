/*---------------------------------------------------------------------
    RTV god rays + volumetric light  (v1.0 rework)
    ------------------------------------------------------------------
    Ray march from the camera to the surface (or GOD_RAYS_DISTANCE for sky pixels), reading the sun shadow map.

    ABOVE WATER - two separate in-scattering terms are accumulated:
      1. SHAFTS  : a sample scatters only when it is lit by the sun AND some neighbours (a few blocks to the side, at the same
                   light depth) are in shadow. This ties the shafts to trees, leaves, windows and gaps between walls.
      2. AIR HAZE: every sun-lit sample adds a small amount of Mie scattering (GOD_RAYS_AIR_SCATTER). It is strongly forward
                   peaked, so it appears as a soft glow around the sun and as faint volumetric light in open air, and it fades
                   with world height (denser near the ground). This is what gives the air real volume instead of only shafts.
      - Phase function is a dual-lobe Henyey-Greenstein (wide + narrow forward lobe).
      - Colour: warm gold that follows the sun; the haze turns slightly cool/blue away from the sun (Rayleigh-like).
      - Golden hour (low sun) boosts density, as in real life (GOD_RAYS_GOLDEN_BOOST).
      - Energy is compressed with 1 - exp(-x) and hard capped, so shafts never become a thick white fog.

    UNDERWATER - sunlight is refracted at the surface (Snell, n = 1.333) and the shafts follow the REFRACTED direction:
      - each sample is traced back along the refracted sun ray to the water surface, where an animated wave pattern
        decides how much light enters. This creates moving, slanted columns of light (like light through a rippling surface)
        on top of the shadow-map edges that terrain and objects cast.
      - colour shifts from bright cyan (shallow / near) to deep blue (far), following water absorption.
      - open-water scattering (UNDERWATER_GOD_RAYS_AMBIENT) keeps columns visible even without nearby occluders.

    Needs: shadowtex1, shadowProjection / shadowModelView (space_transforms.glsl), SUN_BRIGHTNESS and the day helpers
    in settings.glsl, cameraPosition + frameTimeCounter (declared by the final pass) and the Iris uniform `wetness`.
---------------------------------------------------------------------*/

#ifndef RTV_GOD_RAYS_GLSL
#define RTV_GOD_RAYS_GLSL

#if GOD_RAYS == 1

#if CLOUD_STYLE != 1
uniform float wetness;
#endif

// Henyey-Greenstein normalised to 1.0 when looking straight at the sun.
float rtv_gr_phase(float c, float g)
{
    float hg  = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
    float hg1 = (1.0 + g) / ((1.0 - g) * (1.0 - g));
    return hg / hg1;
}

// Dual-lobe phase: a wide lobe for the broad glow plus a narrow lobe for the bright core around the sun.
float rtv_gr_phase_dual(float c, float g_wide, float g_narrow, float narrow_mix)
{
    return mix(rtv_gr_phase(c, g_wide), rtv_gr_phase(c, g_narrow), narrow_mix);
}

// Animated light pattern at the water surface (0..1). Three travelling wave layers with domain warping give soft,
// ridged bands, so the columns look like sunlight focused by ripples instead of a regular grid.
float rtv_uw_shaft_pattern(vec2 p, float t)
{
    float a = sin(p.x * 0.55 + t * 0.90 + sin(p.y * 0.31 - t * 0.50) * 1.70);
    float b = sin(p.y * 0.47 - t * 0.70 + sin(p.x * 0.27 + t * 0.40) * 1.90);
    float c = sin((p.x + p.y) * 0.83 + t * 1.30 + sin((p.x - p.y) * 0.21) * 1.2);
    float v = 0.5 + 0.5 * (0.45 * a + 0.40 * b + 0.15 * c);
    return smoothstep(0.34, 0.80, v);
}

// Shared HDR integration. A low-discrepancy disk keeps neighbouring pixels from receiving unrelated random tap layouts.
vec3 rtv_god_rays_integrate(in vec3 view_dir, in float surface_dist, in vec3 sun_dir,
                            in float jitter, in float jitter2, in bool underwater)
{
    float day = smoothstep(0.0, 0.12, max(rtv_day_cycle(), 0.0));
    float sun_up = smoothstep(0.015, 0.16, sun_dir.y);
    float weather = 1.0 - smoothstep(0.05, 0.60, clamp(wetness, 0.0, 1.0));
    float strength = underwater ? UNDERWATER_GOD_RAYS_STRENGTH : GOD_RAYS_STRENGTH;
    float gate = day * sun_up * weather * strength;
    if (gate < 0.002) return vec3(0.0);

    float low_sun = 1.0 - smoothstep(0.10, 0.60, sun_dir.y);

    float max_distance = underwater ? float(UNDERWATER_GOD_RAYS_DISTANCE) : float(GOD_RAYS_DISTANCE);
    float t_end = min(surface_dist, max_distance);
    const float t_start = 0.6;
    if (t_end <= t_start + 0.5) return vec3(0.0);

    vec2 uv_per_block = vec2(abs(shadowProjection[0][0]), abs(shadowProjection[1][1])) * 0.5;
    float z_bias = 0.08 * 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);

    const int TAPS = GOD_RAYS_TAPS;
    vec2 tap_off[GOD_RAYS_TAPS];
    // Sunflower / golden-angle disk: evenly covers the neighbourhood. Only a tiny stable rotation remains.
    float tap_rotation = (jitter2 - 0.5) * 0.12;
    for (int k = 0; k < TAPS; k++)
    {
        float a = float(k) * 2.399963 + tap_rotation;
        float r = sqrt((float(k) + 0.5) / float(TAPS)) * GOD_RAYS_REACH;
        tap_off[k] = vec2(cos(a), sin(a)) * r * uv_per_block;
    }

    // Underwater: refracted sun direction (light travel direction inside the water) and the slant of the shafts.
    vec3 refr = refract(-sun_dir, vec3(0.0, 1.0, 0.0), 1.0 / 1.333);
    vec2 shift_per_h = refr.xz / max(-refr.y, 0.05);
    float surf_y = max(63.0, cameraPosition.y + 2.0); // sea level, or just above the camera for lakes at altitude

    const int STEPS = GOD_RAYS_STEPS;
    float span = t_end - t_start;
    float inv_n = 1.0 / float(STEPS);
    float accum_shaft = 0.0;
    float accum_air = 0.0;

    // Less jitter amplitude = less per-pixel speckle; the soft shadow test below keeps the remaining banding invisible.
    float jit = 0.5 + (jitter - 0.5) * 0.60;
    vec2 soft_r = uv_per_block * 0.75;

    for (int i = 0; i < STEPS; i++)
    {
        float su0 = (float(i) + jit) * inv_n;
        float su1 = (float(i) + 1.0 + jit) * inv_n;
        float t = t_start + span * su0 * su0;
        float dt = span * (su1 * su1 - su0 * su0);

        vec3 p = view_dir * t;
        vec3 sp = foot_pos_to_shadowmap_texcoord(p);
        if (sp.x < 0.02 || sp.x > 0.98 || sp.y < 0.02 || sp.y > 0.98) continue;
        float z = sp.z - z_bias;
        // Soft lit test: centre + 4 neighbours (<1 block away). The old single hard test flipped between 0 and 1 from one pixel
        // to the next, which was the main source of dotted god rays.
        float lit = step(z, texture(shadowtex1, sp.xy).r);
        lit += step(z, texture(shadowtex1, clamp(sp.xy + vec2( soft_r.x, 0.0), vec2(0.001), vec2(0.999))).r);
        lit += step(z, texture(shadowtex1, clamp(sp.xy + vec2(-soft_r.x, 0.0), vec2(0.001), vec2(0.999))).r);
        lit += step(z, texture(shadowtex1, clamp(sp.xy + vec2(0.0,  soft_r.y), vec2(0.001), vec2(0.999))).r);
        lit += step(z, texture(shadowtex1, clamp(sp.xy + vec2(0.0, -soft_r.y), vec2(0.001), vec2(0.999))).r);
        lit *= 0.2;
        if (lit < 0.01) continue;

        float occ = 0.0;
        for (int k = 0; k < TAPS; k++)
        {
            vec2 q = clamp(sp.xy + tap_off[k], vec2(0.001), vec2(0.999));
            occ += 1.0 - step(z, texture(shadowtex1, q).r);
        }
        occ /= float(TAPS);
        // Higher threshold suppresses isolated one-tap hits (the source of the old dotted look around leaves).
        float near_occluder = smoothstep(0.06, 0.80, occ);

        if (underwater)
        {
            vec3 w = p + cameraPosition;
            float h = max(surf_y - w.y, 0.0);
            float pat = rtv_uw_shaft_pattern(w.xz - shift_per_h * h, frameTimeCounter);
            pat = mix(1.0, pat, UNDERWATER_GOD_RAYS_SHIMMER);

            float density = exp(-t * 0.012);
            // Beams: dark gaps between the ripple bands, so the columns of light are clearly separated.
            float open_water = UNDERWATER_GOD_RAYS_AMBIENT * (0.10 + 0.90 * pat);
            float edge_shafts = (1.0 - UNDERWATER_GOD_RAYS_AMBIENT) * near_occluder * (0.50 + 0.50 * pat);
            accum_shaft += (open_water + edge_shafts) * density * dt * lit;
        }
        else
        {
            float world_y = p.y + cameraPosition.y;
            float density_shaft = exp(-max(p.y, 0.0) * 0.010) * exp(-t * 0.0105);
            accum_shaft += near_occluder * density_shaft * dt * lit;

            // Open-air Mie haze: denser near the ground, thinning with altitude and distance.
            float density_air = exp(-max(world_y - 62.0, 0.0) * 0.016) * exp(-t * 0.0085);
            accum_air += density_air * dt * lit;
        }
    }

    if (underwater)
    {
        float cos_w = dot(view_dir, -refr);
        float phase = 0.16 + 0.84 * rtv_gr_phase_dual(cos_w, 0.55, 0.85, 0.45);
        float amount = 1.0 - exp(-accum_shaft * UNDERWATER_GOD_RAYS_DENSITY * phase);
        amount = min(amount, 0.78);

        // Cyan near / shallow, deep blue far away (water absorbs red first, then green).
        float far_tint = 1.0 - exp(-t_end * 0.030);
        vec3 shallow = mix(vec3(0.55, 0.90, 1.00), vec3(0.66, 0.84, 0.94), low_sun * 0.50);
        vec3 deep = vec3(0.12, 0.50, 0.96);
        vec3 water_beam = mix(shallow, deep, far_tint);
        // Slight extra core brightness when looking along the refracted sun ray.
        water_beam *= 1.0 + 0.55 * pow(max(cos_w, 0.0), 6.0);
        return water_beam * (amount * gate * SUN_BRIGHTNESS * 0.26 * rtv_sky_illumination_factor());
    }

    float cos_sun = dot(view_dir, sun_dir);
    float golden = 1.0 + GOD_RAYS_GOLDEN_BOOST * 0.80 * low_sun;

    // Shafts beside occluders.
    float phase_shaft = 0.30 + 0.70 * rtv_gr_phase_dual(cos_sun, 0.55, 0.80, 0.30);
    vec3 warm = mix(vec3(1.00, 0.85, 0.62), vec3(1.00, 0.66, 0.36), low_sun);
    warm *= rtv_sun_color();
    float amount_shaft = 1.0 - exp(-accum_shaft * GOD_RAYS_DENSITY * phase_shaft * golden);
    amount_shaft = min(amount_shaft, 0.52);

    // Open-air haze: nearly all of its energy sits in the forward lobe, so it reads as a glow around the sun.
    float phase_air = 0.05 + 0.95 * rtv_gr_phase_dual(cos_sun, 0.72, 0.90, 0.40);
    vec3 haze_col = mix(vec3(0.66, 0.80, 1.00), warm, smoothstep(-0.10, 0.85, cos_sun));
    float amount_air = 1.0 - exp(-accum_air * GOD_RAYS_DENSITY * GOD_RAYS_AIR_SCATTER * phase_air * golden);
    amount_air = min(amount_air, 0.30);

    vec3 result = warm * amount_shaft + haze_col * amount_air;
    return result * (gate * SUN_BRIGHTNESS * 0.18 * rtv_sky_illumination_factor());
}

// Above-water shafts + haze: light scattered beside leaves, trees and structures, plus soft volumetric glow in open air.
vec3 rtv_god_rays(in vec3 view_dir, in float surface_dist, in vec3 sun_dir, in float jitter, in float jitter2)
{
    return rtv_god_rays_integrate(view_dir, surface_dist, sun_dir, jitter, jitter2, false);
}

// Underwater shafts: refracted sunlight through a rippling surface, with shadow-edge structure and depth-dependent colour.
vec3 rtv_underwater_god_rays(in vec3 view_dir, in float surface_dist, in vec3 sun_dir, in float jitter, in float jitter2)
{
    #if UNDERWATER_GOD_RAYS == 1
        return rtv_god_rays_integrate(view_dir, surface_dist, sun_dir, jitter, jitter2, true);
    #else
        return vec3(0.0);
    #endif
}

#endif // GOD_RAYS

#endif
