#version 430 compatibility

#define IS_TERRAIN 1
#define IS_CLOUDS 1

#define IS_WATER 1


#define RT_RESOLUTION_DIVIDER 1 //[1 2 4 10 20 100]
#define RT_DENOISING 1 //[1]

#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0


    uniform sampler2D gtexture;

    in vec2 texcoord;
    in vec4 glcolor;

    /* RENDERTARGETS:0,5 */
    layout(location = 0) out vec4 color;
    layout(location = 1) out vec4 normals_face_world_and_material_id_tex; //normals_face_world, material id

    void main() {
	    color = texture(gtexture, texcoord) * glcolor;
	    normals_face_world_and_material_id_tex = vec4(0.,-1.,0., 41.);
	    if (color.a < 0.1) {
		    discard;
	    }
    }

#else

    #include "/programs/main_f.glsl"

#endif
