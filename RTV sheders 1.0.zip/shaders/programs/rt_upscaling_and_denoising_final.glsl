// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


// RT Upscaling & Denoising (2 of 2 files)

// Purpose:
	// RT Upscale & Denoising: 

		// When running low res RT or Denoising:
			// the Primary Deferred Pass doesn't add lighting to the scene, it defers it
			// this pass runs. as a last or only denoising / upscaling pass. there is a similiar file for the previous passes, if any
				// this pass samples the defered lighting and applies it
					// because ALL lighting is deferred and then applied here, there will probably be loss of quality in direct lighting vs if it was calculated at full res
						// it would be better to maybe seperate out direct sun lighting since it doesn't have to be RT,
						// but then it wouldn't get denoised here
		
		
	// This could be done a lot better, this is the simplest way to denoise lighting that I could think of


// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
    uniform vec3 skyColor;
	uniform vec3 cameraPosition;
	uniform vec3 previousCameraPosition;
	uniform vec3 shadowLightPosition;
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform vec3 fogColor; //underwater this is the biome's water color
	uniform bool hideGUI;
	uniform ivec2 eyeBrightnessSmooth;
	uniform float viewWidth;
	uniform float viewHeight;
    uniform float frameTimeCounter;
    #define RTV_FRAMETIME_DECLARED 1
	uniform float near;
	uniform float far;

// Samplers / Textures / Images
	
	//depth
	uniform sampler2D  depthtex0;
	
	//working scene image
    uniform sampler2D colortex0; // scene image
	
	//defered data
    uniform sampler2D colortex1; // albedo
    uniform sampler2D colortex2; // specular tex 
    uniform sampler2D colortex3; // normals tex (in world space) 
    uniform sampler2D colortex4; // defered_data_1_tex; // vec4(lmcoord,ao,height_map);
	uniform sampler2D colortex5; // vec4 normals_face_world, float material_mask_id
	#if DENOISING_PASSES > 1
        //we have flaggedif there are multiple passes, so that we can do things differently 
			//if this is the first and only pass, it needs to sample the (low res) trace Data in colortex6
			//if it is a second or third pass, it needs to sample the upscaled data in colortex7, to process it again
			
        uniform sampler2D colortex7; // full res hdr lighting that is already partially upscaled/denoised
		// we are going to use a define trick to load from a different sampler without having to change the code after thos point 
        #define LIGHT_SAMPLER colortex7
		//we likewise change the variable we use for knowing the resolution of the input
        #define ACTIVE_RT_RESOLUTION_DIVIDER 1 
    #else
		//if this is the first pass, it samples the (low res) colortex6, at its given resolution
        #define LIGHT_SAMPLER colortex6
        #define ACTIVE_RT_RESOLUTION_DIVIDER int(RT_RESOLUTION_DIVIDER)
    #endif
	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	//our 3d image with voxel data as an interpolated sampler
	uniform usampler3D cSampler1;

// Data from Vertex Shader
    in vec2 texcoord;
	
// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;

// Outputs
	/* RENDERTARGETS:0 */
	layout(location = 0) out vec4 color;

// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
	#define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/voxelizing/emitters.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/noise/noise_functions.glsl"
	#include "/stuff/reprojection.glsl"
	#if CLOUD_STYLE == 1
		#include "/stuff/volumetric_clouds.glsl"
	#endif
	#include "/stuff/god_rays.glsl"




// Functions
	void progress_dither()
	{
		#if TEMPORAL_ACCUMULATION > 0
			Dither_offset = fract(Dither_offset + random_from_vec2(gl_FragCoord.xy) );
		#endif
	}
	
	vec3 get_screen_dither()
	{	
		#if DITHER_TYPE == 1 || DITHER_TYPE == 3 
			return blue_noise().xyz;
		#endif
		#if DITHER_TYPE == 2
			return vec3(
				random_from_vec2(gl_FragCoord.xy),
				random_from_vec2(gl_FragCoord.xy*(1.238+texcoord)),
				random_from_vec2(gl_FragCoord.xy*(3.1497+texcoord))
				);
		#endif
	}
	
	float linearize_depth(in float d)
	{
		// from gl_FragCoord.z to world measurements
		return 2.0 * near  * far / (far + near - (2.0 * d - 1.0) * (far - near));
	}
	




#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
// Phone fix: the voxel images are cleared here by hand, at the end of the frame, after every ray has been traced.
// Iris clears them with glClearTexImage, which GLES / MobileGlues may not do, leaving random or stale voxels
// (and imageAtomicMax can never lower a value). Stale voxels are what bounced rainbow colors around the scene.
// Every pixel clears a few voxels; the next frame's shadow pass then voxelizes into zeroed images.
void rtv_clear_voxel_images()
{
	int per_frame = max(int(viewWidth) * int(viewHeight), 1);
	int pix = int(gl_FragCoord.y) * int(viewWidth) + int(gl_FragCoord.x);

	const int voxel_total = VOXEL_AREA * VOXEL_AREA * VOXEL_AREA;
	for(int i = pix; i < voxel_total; i += per_frame)
	{
		ivec3 p = ivec3(i % VOXEL_AREA, (i / VOXEL_AREA) % VOXEL_AREA, i / (VOXEL_AREA * VOXEL_AREA));
		imageStore(cimage1, p, uvec4(0u));
	}

	#if RT_BLOCK_LIGHT_NEE == 1
		// the emitter grid (one uint per 3x3x3 blocks)
		const int emitter_w = RTV_EMITTER_GRID * 2; //two slots per cell, side by side in x
		const int emitter_total = emitter_w * RTV_EMITTER_GRID * RTV_EMITTER_GRID;
		for(int i = pix; i < emitter_total; i += per_frame)
		{
			ivec3 p = ivec3(i % emitter_w, (i / emitter_w) % RTV_EMITTER_GRID, i / (emitter_w * RTV_EMITTER_GRID));
			imageStore(c_image_emitters, p, uvec4(0u));
		}
	#endif

	#if VOXEL_LODS >= 1 && RT_API >= 6
		// the LOD bitmask image: one uint covers a 4 x 2 x 4 block of voxels
		const ivec3 lod_dim = ivec3(VOXEL_AREA / 4, VOXEL_AREA / 2, VOXEL_AREA / 4);
		const int lod_total = lod_dim.x * lod_dim.y * lod_dim.z;
		for(int i = pix; i < lod_total; i += per_frame)
		{
			ivec3 p = ivec3(i % lod_dim.x, (i / lod_dim.x) % lod_dim.y, i / (lod_dim.x * lod_dim.y));
			imageStore(c_image_voxel_lod_1, p, uvec4(0u));
		}
	#endif
}
#endif


// ---------------------------------------------------------------------------------------------
// Underwater helpers (used by the underwater block in main())
// ---------------------------------------------------------------------------------------------
float uw_hash13(vec3 p)
{
	p = fract(p * 0.1031);
	p += dot(p, p.zyx + 31.32);
	return fract((p.x + p.y) * p.z);
}

// Sharp, animated caustic network (iterated sine domain warp). Tiles seamlessly in world space.
float uw_caustic_tile(vec2 uv, float t)
{
	vec2 p = mod(uv * 6.28318530718, 6.28318530718) - 250.0;
	vec2 i = p;
	float c = 1.0;
	const float inten = 0.005;
	for (int n = 0; n < 4; n++)
	{
		float tt = t * (1.0 - (3.5 / float(n + 1)));
		i = p + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
		c += 1.0 / length(vec2(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
	}
	c /= 4.0;
	c = 1.17 - pow(c, 1.4);
	return clamp(pow(abs(c), 8.0), 0.0, 1.0);
}

// Three broad world-space layers. The old 0.22 / 0.15 scales repeated every
// few blocks and produced visible square patches on the river bed. Larger,
// incommensurate scales keep the caustic flow organic across block boundaries.
float uw_caustic_pattern(vec2 p, float t)
{
	float a = uw_caustic_tile(p * 0.075, t * 0.50 + 23.0);
	vec2 q = vec2(p.x * 0.8 - p.y * 0.6, p.x * 0.6 + p.y * 0.8);
	float b = uw_caustic_tile(q * 0.052 + 7.3, t * 0.37 + 11.0);
	vec2 r = vec2(p.x * 0.53 + p.y * 0.85, -p.x * 0.85 + p.y * 0.53);
	float c = uw_caustic_tile(r * 0.105 + 13.1, t * 0.29 + 37.0);
	return clamp(0.48 * a + 0.34 * b + 0.18 * c, 0.0, 1.0);
}

// Floating plankton / marine snow. Each unit cell along the view ray holds at most one tiny particle;
// the closest approach of the ray to that particle decides how bright the pixel is.
float uw_particles(vec3 origin, vec3 dir, float max_dist, float t)
{
	float acc = 0.0;
	for (int k = 0; k < 8; k++)
	{
		vec3 s = origin + dir * (float(k) + 0.5);
		vec3 cell = floor(s);
		float h = uw_hash13(cell);
		if (h < 0.62) continue; // density: ~38% of the cells hold a particle
		vec3 centre = cell + 0.15 + 0.70 * vec3(h, fract(h * 7.31), fract(h * 13.17));
		centre += 0.10 * vec3(sin(t * 0.40 + h * 20.0), sin(t * 0.33 + h * 31.0), cos(t * 0.37 + h * 17.0));
		vec3 to_p = centre - origin;
		float along = dot(to_p, dir);
		if (along < 0.4 || along > max_dist) continue; // behind the camera / behind the scenery
		float miss = length(to_p - dir * along);
		float radius = max(0.022, 0.0016 * along);
		float twinkle = 0.55 + 0.45 * sin(t * 1.6 + h * 40.0);
		acc += smoothstep(radius, radius * 0.15, miss) * twinkle * exp(-along * 0.16);
	}
	return acc;
}

// Main Function

void main()
{
	#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
		rtv_clear_voxel_images(); // (off while the debug panels are on, they read the voxel image in this same pass)
	#endif
	// This is just Copy-Pasted from the Deferred Primary Pass, and poorly pruned
	
	
	// Setup
	
		vec3 Debug_value; //so we can debug locally coped stuff at the end of the function
		
		#if RAYTRACING_VIEW == 1
			//we are ray tracing the right half of the screen, so ignore it here
			if(texcoord.x<=.5)
			{
		#endif
		#if RAYTRACING_VIEW == 2
			//we are ray tracing the entire screen, so ignore it here
			if(false)
			{
		#endif
        
    // Load data and unpack
		float depth_tex_read = texture(depthtex0,texcoord).r;

		vec4 albedo = texture(colortex1, texcoord);
		vec4 specular_tex = texture(colortex2, texcoord);
		//vec4 defered_data_1_tex = texture(colortex4, texcoord);
		//vec2 lmcoord = defered_data_1_tex.xy;
		vec4 deferred_data2 =  texture(colortex5, texcoord);
		vec3 normals_face_world = deferred_data2.xyz;
		float material_mask_id = deferred_data2.a;
		vec3 normals_texture_world = texture(colortex3, texcoord).xyz;

		bool primary_ray_hit = depth_tex_read <1. && abs(material_mask_id-41.) > .5;

		//unpack 
		albedo.rgb = srgb_to_linear(albedo.rgb);
		float sss = specular_tex.b < 64.5? specular_tex.b/64. : 0.;
		
		float emmission = specular_tex.a * BLOCK_LIGHT_BRIGHTNESS; //emission

	// Setup
	
		vec3 view_dir_world;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 direction_screen = vec3(texcoord, 1.);
				vec3 direction_view = screen_to_view_space(direction_screen);
				view_dir_world = normalize( view_to_foot_direction(direction_view) );
			}

		// fix imposible viewing angles from normal textues that point away from the camera
		if( dot(normals_texture_world,view_dir_world) > 0. )  normals_texture_world = normals_face_world;

		#if USE_TEXTURE_NORMALS == 0
			normals_texture_world = normals_face_world;
		#endif
		
		vec3 foot_pos;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 position_screen = vec3(texcoord, depth_tex_read);
				vec3 position_view = screen_to_view_space(position_screen);
				foot_pos = view_to_foot_space(position_view);
			}

		//Load a Dither / Randomness / Offset
		Dither_offset = get_screen_dither();
		//change per frame
		#if TEMPORAL_ACCUMULATION > 0
			#if TEMPORAL_ACCUMULATION == 1
				if(hideGUI) Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#else
				Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#endif
		#endif
			
	// Apply our lighting
	
		//get sun direction in the world
		Sun_or_moon_dir_world = normalize(
				view_to_foot_direction(shadowLightPosition)
				 #if SOFT_RT_SHADOWS == 1 && SHADOWS_USED_ON_SCREEN == 1
					+ SUN_WIDTH * (2.*Dither_offset.xyz-1.)
				#endif
			);
					
		//Load & Upscale Lighting
		vec3 lighting_last = RTV_SAFE3(texture(LIGHT_SAMPLER,texcoord).rgb, 10000.);

		vec3 lighting = lighting_last;
		#if RT_DENOISING == 1
		// OPTIMISATION (identical result): sky pixels (and mask 41) are overwritten with the sky colour further down,
		// so the whole (2K+1)^2 denoise loop is skipped for them. Constants of the centre pixel are computed once
		// instead of once per tap, and a tap whose geometric weight is already zero skips its light fetch.
		if (primary_ray_hit)
		{
			ivec2 uv = ivec2(gl_FragCoord.xy);
			ivec2 depth_size = textureSize(depthtex0, 0);
			ivec2 depth_max_uv = max(depth_size - ivec2(1), ivec2(0));
			ivec2 light_size = textureSize(LIGHT_SAMPLER, 0);
			ivec2 light_max_uv = max(light_size - ivec2(1), ivec2(0));

			float total_weight = 0.;
			vec3 sampled_color = vec3(0.);

			// centre-pixel constants
			float c_lin_depth = linearize_depth(depth_tex_read);
			float c_depth_tol = 0.25 + 0.10 * c_lin_depth;
			float center_is_water = 1.0 - step(0.5, abs(material_mask_id - 1.0));
			float center_is_hand = step(100.5, abs(material_mask_id));
			float center_is_entity = 1.0 - step(0.5, abs(material_mask_id - 100.0));
			const vec3 luma_w = vec3(0.2126, 0.7152, 0.0722);
			vec3 center_water_color = max(RTV_SAFE3(lighting_last, 10000.0), vec3(0.0));
			float center_water_luma = dot(center_water_color, luma_w);
			float center_water_log = log2(1.0 + center_water_luma);
			vec3 center_water_chroma = center_water_color / max(center_water_luma, 0.05);
			float kernel_norm = float(max(1, RT_DENOISING_KERNEL_SIZE + RT_DENOISING_KERNEL_SIZE));

			for(int x = -RT_DENOISING_KERNEL_SIZE ; x<= RT_DENOISING_KERNEL_SIZE ; x++)
			{
				for(int y = -RT_DENOISING_KERNEL_SIZE ; y<= RT_DENOISING_KERNEL_SIZE ; y++)
				{
					// water: the see-through image (sea floor) must stay sharp, so water pixels only blend with their nearest neighbors
					if (center_is_water > 0.5 && max(abs(x), abs(y)) > WATER_DENOISE_RADIUS) continue;
					float kblur = max(0.0, 1.0 - KERNEL_FADE * float(abs(x) + abs(y)) / kernel_norm);

					ivec2 n_uv = clamp(uv + ivec2(x, y) * max(1, ACTIVE_RT_RESOLUTION_DIVIDER),
					                   ivec2(0), depth_max_uv);
					vec3 normals2 = texelFetch(colortex3, n_uv, 0).rgb;
					float depth_tex_read2 = texelFetch(depthtex0, n_uv, 0).r;
					float neighbor_material_mask_id = texelFetch(colortex5, n_uv, 0).a;

					float neighbor_is_water = 1.0 - step(0.5, abs(neighbor_material_mask_id - 1.0));
					float water_region_match = 1.0 - abs(center_is_water - neighbor_is_water);
					// Keep first-person hand/item samples separate from the world behind them.
					float neighbor_is_hand = step(100.5, abs(neighbor_material_mask_id));
					float hand_region_match = 1.0 - abs(center_is_hand - neighbor_is_hand);
					// Mask 100 is a mob/entity; do not mix its denoising samples with terrain.
					float neighbor_is_entity = 1.0 - step(0.5, abs(neighbor_material_mask_id - 100.0));
					float entity_region_match = 1.0 - abs(center_is_entity - neighbor_is_entity);

					float w = kblur
						* pow( max(0., dot(normals2,normals_texture_world) ),RT_DENOISING_NORMALS_EXP)
						* max(0., 1. - abs(linearize_depth(depth_tex_read2) - c_lin_depth) / c_depth_tol)
						* hand_region_match
						* entity_region_match
						* water_region_match;

					bool is_center = (x == 0 && y == 0);
					if (!is_center && w <= 0.0) continue; // contributes exactly zero: skip the light fetch

					vec3 lighting_sample2 = RTV_SAFE3(texelFetch(LIGHT_SAMPLER, clamp(n_uv / ACTIVE_RT_RESOLUTION_DIVIDER, ivec2(0), light_max_uv), 0).rgb, 10000.);

					// Water-only bilateral weighting preserves colour boundaries in reflected silhouettes.
					if (center_is_water > 0.5)
					{
						vec3 sample_c = max(lighting_sample2, vec3(0.0));
						float sample_water_luma = dot(sample_c, luma_w);
						float water_luma_edge = abs(center_water_log - log2(1.0 + sample_water_luma));
						vec3 sample_water_chroma = sample_c / max(sample_water_luma, 0.05);
						float water_chroma_edge = min(length(center_water_chroma - sample_water_chroma), 2.0);
						w *= 1.0 - 0.55 * smoothstep(0.42, 1.15, water_luma_edge + 0.10 * water_chroma_edge);
					}

					else
					{
						// luminance edge-stop (see DENOISER_LUMA_EDGE): keep real lighting detail. The 0.2 floor means a neighbour is never fully
						// rejected, so isolated bright samples (fireflies) still get averaged away.
						float luma_dl = abs(center_water_log - log2(1.0 + dot(max(lighting_sample2, vec3(0.0)), luma_w)));
						w *= mix(0.2, 1.0, exp(-2.0 * luma_dl * luma_dl * DENOISER_LUMA_EDGE * DENOISER_LUMA_EDGE));
					}

					if (is_center) w = max(w, 0.0001);
					sampled_color += lighting_sample2 * w;
					total_weight += w;
				}
			}

			lighting = clamp(sampled_color / max(total_weight, 0.001), 0.0, 10000.0);
		}
		#endif

        #if DENOISE_REFRACTIONS == 0
            if(albedo.a<.999) lighting.rgb = lighting_last.rgb;
        #endif

        // Noise-gated detail restoration: the spatial filter keeps GI speckles down, while this
        // restores only stronger luminance structure from the center sample. Tiny residual noise
        // stays below the dead-zone; the gain is capped to avoid bright/dark halos.
        #if RT_DENOISING == 1
            if (abs(material_mask_id - 1.0) > 0.5)
            {
                float filtered_luma = dot(max(lighting, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
                float center_luma = dot(max(lighting_last, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
                float luma_detail = center_luma - filtered_luma;
                float detail_dead_zone = max(0.018, filtered_luma * 0.025);
                float restored_detail = sign(luma_detail) * max(abs(luma_detail) - detail_dead_zone, 0.0);
                float detail_gain = clamp(1.0 + RT_DENOISING_SHARPEN * restored_detail / max(filtered_luma, 0.05), 0.88, 1.12);
                lighting *= detail_gain;
            }
        #endif


		//To apply the lighting we need the tint of the bounced light (albedo for diffuse, white for mirror-like reflection).
		// This MUST be smooth and deterministic: it is applied AFTER denoising and temporal accumulation, so nothing can average it out.
		// (It used to be re-rolled here from a random scattered ray direction, which gave every pixel a different random white tint
		// every frame: the white / pink / blue moving dots on grass.)
		// Rough surfaces (grass, dirt, leaves...) have no fresnel sheen, only smooth ones (water, glass, ice, polished metal) do.
		float tint_smoothness = specular_tex.r * specular_tex.r;
		float fresnel = pow( max(0., dot( view_dir_world, reflect(view_dir_world, normals_texture_world))) ,6.) * tint_smoothness;
		float shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;

		//tinting of bounced light, light is tinted when it diffuses into a surface or bounces off metal 
		vec3 tinting = 
			(specular_tex.g>229.6/255.) ? 
			mix(albedo.rgb, vec3(1.), fresnel) //metals
			:
			mix(albedo.rgb, vec3(1.), shininess); //non-metals
		
		
		//Apply the lighting. Compress the emissive peak without changing its RGB ratios.
        vec3 emission_color = max(mix(vec3(dot(albedo.rgb, vec3(0.2126, 0.7152, 0.0722))), albedo.rgb, EMISSION_SATURATION), vec3(0.0));
        vec3 emissive_radiance = rtv_soft_compress_radiance(emmission * emission_color * EMISSION_STRENGTH);
		color.rgb = lighting * tinting + emissive_radiance;

		// ---- light reflected from water onto walls and ceilings ----
		// Sunlight hits a water surface and bounces up: for a wall pixel we look back along the mirrored sun direction through the voxel scene.
		// If that ray meets water first (and the sun can see that spot of water) the wall gets a soft, rippling patch of light.
		// Solid blocks in between stop it, so it never leaks through walls.
		#if WATER_LIGHT_ON_WALLS == 1
		if(isEyeInWater == 0 && primary_ray_hit && material_mask_id < 100.5 && abs(material_mask_id - 1.0) > 0.5)
		{
			float wl_sun = smoothstep(0.14, 0.42, Sun_or_moon_dir_world.y) * rtv_sunlight_factor();
			float wl_surface = 1.0 - smoothstep(0.45, 0.85, normals_face_world.y);   // walls and ceilings, not floors
			vec3 wl_dir = vec3(Sun_or_moon_dir_world.x, -Sun_or_moon_dir_world.y, Sun_or_moon_dir_world.z);
			float wl_facing = dot(normals_face_world, wl_dir);
			if(wl_sun > 0.001 && wl_surface > 0.001 && wl_facing > 0.05 && length(foot_pos) < 56.0)
			{
				vec3 wl_offset = vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition);
				vec3 wl_origin = foot_pos + normals_face_world * 0.12 + wl_offset;
				float wl_jitter = get_screen_dither().x;
				float wl_hit_dist = -1.0;
				for(int wi = 0; wi < 18; wi++)
				{
					float wd = (float(wi) + wl_jitter) * 0.85 + 0.2;
					vec3 wp = wl_origin + wl_dir * wd;
					ivec3 wv = ivec3(floor(wp));
					if(clamp(wv, 0, VOXEL_AREA - 1) != wv) break;
					uint wdata = imageLoad(cimage1, wv).r;
					if(wdata != 0u)
					{
						uint wmat = unpack_material_flag_from_voxel(wdata);
						if(wmat == 1u) { wl_hit_dist = wd; break; }       // water: the light comes from here
						if(wmat != 3u) break;                               // anything solid blocks it (clear glass lets it pass)
					}
				}
				if(wl_hit_dist > 0.0)
				{
					vec3 wl_water_foot = foot_pos + normals_face_world * 0.12 + wl_dir * wl_hit_dist;
					// can the sun reach that piece of water?
					vec3 wl_sh = foot_pos_to_shadowmap_texcoord(wl_water_foot + Sun_or_moon_dir_world * 0.6);
					wl_sh.z -= 0.35 * 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);
					float wl_lit = step(wl_sh.z, texture(shadowtex1, clamp(wl_sh.xy, vec2(0.001), vec2(0.999))).r);
					float wl_edge = max(abs(wl_sh.x * 2.0 - 1.0), abs(wl_sh.y * 2.0 - 1.0));
					wl_lit = mix(1.0, wl_lit, 1.0 - smoothstep(0.90, 1.0, wl_edge));
					// moving ripple pattern (same family as the underwater caustics) measured on the water surface
					vec2 wl_p = (wl_water_foot + cameraPosition).xz;
					float wl_pattern = 0.20 + 0.95 * uw_caustic_pattern(wl_p * 0.9, frameTimeCounter);
					float wl_reflectance = 0.16 + 0.84 * pow(1.0 - clamp(Sun_or_moon_dir_world.y, 0.0, 1.0), 4.0);
					float wl_dist_fade = exp(-wl_hit_dist * 0.07);
					float wl_amount = wl_lit * wl_pattern * wl_reflectance * wl_dist_fade * wl_sun * wl_surface * clamp(wl_facing, 0.0, 1.0) * WATER_LIGHT_ON_WALLS_STRENGTH;
					vec3 wl_color = mix(vec3(1.0), vec3(0.55, 0.85, 1.0), 0.45) * rtv_sun_color();
					color.rgb += albedo.rgb * wl_color * (SUN_BRIGHTNESS * 0.22 * wl_amount);
				}
			}
		}
		#endif
		#if RTV_PHONE == 1
			color.rgb = rtv_safe3(color.rgb, 1000000.); //phone: a NaN pixel must never reach the screen
		#endif
			
	
	//Sky & background
	
	if(!primary_ray_hit )
	{
	// Add background
		vec4 bg = texture(colortex0, texcoord) ;
		#if TONEMAPPING > 0
			bg.rgb = srgb_to_linear(bg.rgb) * (SUN_BRIGHTNESS * rtv_sky_illumination_factor());
		#endif

		color.rgb = bg.rgb;

		// Volumetric clouds. They have to be drawn HERE: the deferred pass only writes the ray traced lighting buffers when denoising is on
		// (its 'color' is a throw-away local), so clouds drawn there never reached the screen.
		#if CLOUD_STYLE == 1
		{
			vec3 cloud_sun_dir = normalize(view_to_foot_direction(shadowLightPosition));
			// static blue-noise jitter (no per-frame offset): the sky is not temporally accumulated, so a moving jitter would shimmer
			vec4 cloud = rtv_volumetric_clouds(normalize(view_dir_world), cloud_sun_dir, get_screen_dither().x);
			#if TONEMAPPING > 0
				color.rgb = color.rgb * cloud.a + cloud.rgb * SUN_BRIGHTNESS;
			#else
				color.rgb = color.rgb * cloud.a + linear_to_srgb(clamp(cloud.rgb * 0.62, 0.0, 1.0));
			#endif
		}
		#endif
	}

	// God rays (above water only). Added in HDR before tonemapping; sky pixels march to GOD_RAYS_DISTANCE, surfaces to their own depth.
	#if GOD_RAYS == 1
	if(isEyeInWater == 0 && material_mask_id < 100.5)
	{
		vec3 gr_noise = get_screen_dither();
		float gr_dist = primary_ray_hit ? length(foot_pos) : float(GOD_RAYS_DISTANCE);
		color.rgb += rtv_god_rays(normalize(view_dir_world), gr_dist, Sun_or_moon_dir_world, gr_noise.x, gr_noise.y);
	}
	#endif

	// Underwater volume (rewritten):
	//  - fog / scattering is scaled to the scene's HDR range (the old values were ~1/30 of what is needed, so the water looked like air)
	//  - sunlight reaching the sea floor fades with depth (vanilla sky light drops 1 level per water block)
	//  - caustics are multiplied onto the lit surfaces, with a sharp animated network, instead of only into the fog
	//  - underwater volumetric shafts: refracted sun columns with animated ripple pattern (see god_rays.glsl)
	//  - drifting plankton particles and a soft vignette
	if(isEyeInWater == 1)
	{
		float uw_density = 1.0 / max(UNDERWATER_VISIBILITY, 0.5);
		float uw_dist = primary_ray_hit ? length(foot_pos) : 64.0;
		uw_dist = clamp(uw_dist, 0.0, 160.0);
		float uw_time = frameTimeCounter;
		vec3 uw_view = normalize(view_dir_world);
		// Thin residual haze only: clear water should keep the terrain readable at normal swimming depths.
		float uw_fog = 1.0 - exp(-uw_dist * 0.028 * uw_density * UNDERWATER_FOG_STRENGTH);

		// Share the exact blue-cyan palette used by the visible water surface.
		// The biome hue remains a small modifier, while depth absorption supplies the natural blue shift.
		float uw_biome_max = max(max(fogColor.r, fogColor.g), fogColor.b);
		vec3 uw_hue = uw_biome_max > 0.001 ? fogColor / uw_biome_max : vec3(0.12, 0.62, 1.0);
		vec3 uw_surface_base = mix(vec3(0.72, 0.88, 0.94), vec3(0.16, 0.43, 0.60), WATER_TINT);
		vec3 uw_color = mix(uw_surface_base, uw_surface_base * (0.62 + 0.38 * uw_hue), 0.30);
		vec3 uw_color_norm = uw_color / max(max(uw_color.r, uw_color.g), uw_color.b);

		// Light available where the player is: dark in caves / at night, bright near the surface in daytime.
		float uw_sky = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
		float uw_light = mix(0.03, 1.0, uw_sky * uw_sky);
		float uw_scale = SUN_BRIGHTNESS * rtv_sky_illumination_factor(); // HDR scale of the scene

		// Beer-Lambert absorption: red goes first, blue last.
		// Same coefficients as the water seen from above (deferred pass), so the sea floor has the same colour whether you look at it
		// through the surface or from inside the water. (It used to be half as strong, which made the inside look flat and clear.)
		vec3 uw_absorb = exp(-vec3(0.120, 0.045, 0.022) * WATER_ABSORPTION * uw_density * uw_dist);

		// ---- surfaces: depth dimming + caustics ----
		vec2 uw_lm = texture(colortex4, texcoord).xy;
		bool uw_world_hit = primary_ray_hit && material_mask_id < 100.5 && abs(material_mask_id - 1.0) > 0.5;
		if(uw_world_hit)
		{
			// Direct sun is shadow-mapped, so without this a sea floor 20 blocks down is as bright as dry land.
			color.rgb *= mix(0.30, 1.0, smoothstep(0.15, 0.95, uw_lm.y));

			vec3 uw_world_pos = foot_pos + cameraPosition;
			vec3 uw_abs_normal = abs(normals_face_world);
			vec2 caustic_p;
			if(uw_abs_normal.y >= uw_abs_normal.x && uw_abs_normal.y >= uw_abs_normal.z)
				caustic_p = uw_world_pos.xz;
			else if(uw_abs_normal.x >= uw_abs_normal.z)
				caustic_p = uw_world_pos.zy;
			else
				caustic_p = uw_world_pos.xy;

			// Keep the bright network narrow and feathered; broad, high-contrast patches looked blocky.
			float caustic_raw = uw_caustic_pattern(caustic_p, uw_time);
			float caustic_pattern = smoothstep(0.30, 0.88, caustic_raw);
			float upward_surface = clamp(normals_face_world.y, 0.0, 1.0);
			float caustic_surface_mask = mix(0.12, 1.0, smoothstep(0.10, 0.82, upward_surface));
			float caustic_depth_fade = exp(-uw_dist * 0.015 * uw_density);
			float caustic_sky_gate = smoothstep(0.28, 0.84, uw_lm.y) * rtv_sunlight_factor();

			// Green, highly saturated texels are usually seagrass, kelp, leaves or foliage.
			// Reduce the caustic overlay there to preserve their silhouettes and texture.
			float uw_albedo_max = max(max(albedo.r, albedo.g), albedo.b);
			float uw_albedo_min = min(min(albedo.r, albedo.g), albedo.b);
			float uw_green_dominance = clamp((albedo.g - max(albedo.r, albedo.b) * 0.82) / max(albedo.g, 0.08), 0.0, 1.0);
			float uw_green_chroma = (uw_albedo_max - uw_albedo_min) / max(uw_albedo_max, 0.08);
			float uw_vegetation_mask = smoothstep(0.10, 0.36, uw_green_dominance)
				* smoothstep(0.16, 0.42, uw_green_chroma);
			float caustic_material_mask = mix(1.0, 0.30, uw_vegetation_mask);

			float caustic_amount = clamp(caustic_pattern * caustic_surface_mask
				* caustic_depth_fade * caustic_sky_gate * caustic_material_mask
				* UNDERWATER_CAUSTICS_STRENGTH, 0.0, 0.90);
			color.rgb *= 1.0 + 0.85 * caustic_amount * vec3(0.90, 0.99, 1.08);
		}

		// ---- scattering fog ----
		// Scattered light is NOT the same in every direction: looking up you see bright cyan light filtering down from the surface,
		// looking down you see dark, deep, blue-shifted water. This vertical gradient is what gives the volume its depth.
		float uw_up = smoothstep(0.10, 0.95, uw_view.y * 0.5 + 0.5);
		vec3 uw_scatter_deep = uw_color * vec3(0.55, 0.75, 1.00) * 0.10;
		vec3 uw_scatter_up = uw_color_norm * vec3(0.55, 0.95, 1.00) * 0.46;
		vec3 uw_scatter = mix(uw_scatter_deep, uw_scatter_up, uw_up) * uw_scale * uw_light;
		// Snell's window: looking up (within ~48 degrees of straight up) you see the bright world above through the surface,
		// with a slowly moving ripple. Outside that cone the surface acts like a dark mirror.
		float uw_window = smoothstep(0.60, 0.72, uw_view.y);
		float uw_ripple = 0.80 + 0.20 * sin(uw_view.x * 22.0 + uw_time * 1.4) * sin(uw_view.z * 19.0 - uw_time * 1.1);
		uw_scatter *= 1.0 + 1.1 * UNDERWATER_SURFACE_WINDOW * uw_window * uw_ripple;
		uw_scatter *= 1.0 - 0.25 * UNDERWATER_SURFACE_WINDOW * smoothstep(0.55, 0.30, uw_view.y) * smoothstep(-0.2, 0.2, uw_view.y);

		// ---- plankton / marine snow ----
		vec3 uw_plankton = vec3(0.0);
		if(UNDERWATER_PARTICLES > 0.0)
		{
			float uw_p = uw_particles(cameraPosition, uw_view, primary_ray_hit ? length(foot_pos) : 12.0, uw_time);
			uw_plankton = mix(vec3(0.85, 1.0, 1.0), uw_color_norm, 0.35) * (uw_p * uw_scale * 0.16 * (0.25 + 0.75 * uw_light) * UNDERWATER_PARTICLES);
		}

		vec3 uw_transmitted = color.rgb * uw_absorb;
		vec3 uw_hue_filter = mix(vec3(1.0), uw_color_norm, 0.10 * uw_fog);
		color.rgb = uw_transmitted * uw_hue_filter
			+ uw_scatter * uw_fog + uw_plankton;

		// Directional underwater shafts are added after water transmission, in HDR.
		// Their contribution is water-depth gated and also follows the sky-light level,
		// so they disappear naturally at night and in enclosed / deeply shadowed water.
		#if UNDERWATER_GOD_RAYS == 1 && GOD_RAYS == 1
		vec3 uw_gr_noise = get_screen_dither();
		float uw_gr_dist = primary_ray_hit ? length(foot_pos) : float(UNDERWATER_GOD_RAYS_DISTANCE);
		vec3 uw_gr = rtv_underwater_god_rays(uw_view, uw_gr_dist, Sun_or_moon_dir_world, uw_gr_noise.x, uw_gr_noise.y);
		float uw_gr_depth_gate = smoothstep(1.0, 7.0, uw_dist) * (0.65 + 0.35 * uw_fog);
		// The vanilla sky light drops 1 level per water block, so the old uw_light gate (sky^2) killed the shafts a few blocks down.
		// Shafts need a gentler gate: still dark in caves / enclosed water, but visible at normal swimming depth.
		float uw_gr_light = smoothstep(0.03, 0.30, uw_sky) * mix(0.60, 1.0, uw_sky);
		color.rgb += uw_gr * uw_gr_light * uw_gr_depth_gate;
		#endif

		// Soft lens vignette: darker, bluer corners add depth.
		vec2 uw_screen = (texcoord - 0.5) * vec2(viewWidth / max(viewHeight, 1.0), 1.0);
		float uw_edge = smoothstep(0.30, 1.05, length(uw_screen));
		float uw_vig = uw_edge * 0.14 * UNDERWATER_VIGNETTE * (0.5 + 0.5 * uw_fog);
		color.rgb = mix(color.rgb, color.rgb * uw_color_norm * 0.80, uw_vig * 1.5) * (1.0 - uw_vig * 0.5);
	}


    // ---- restrained aerial perspective ----
    // Adds a small sky-coloured distance cue without blurring terrain or marching extra rays.
    // Sky visibility gates it out in caves; water / entities / hand are excluded.
    if (AERIAL_PERSPECTIVE_STRENGTH > 0.0 && primary_ray_hit && isEyeInWater == 0 && material_mask_id < 100.5 && abs(material_mask_id - 1.0) > 0.5)
    {
        float aerial_distance = length(foot_pos);
        if (aerial_distance > 112.0)
        {
            float aerial_sky_access = texture(colortex4, texcoord).g;
            float aerial_horizon = 1.0 - smoothstep(0.10, 0.72, abs(view_dir_world.y));
            float aerial_amount = smoothstep(112.0, 420.0, aerial_distance)
                * AERIAL_PERSPECTIVE_STRENGTH
                * smoothstep(0.06, 0.42, aerial_sky_access)
                * mix(0.30, 1.0, aerial_horizon);
            vec3 aerial_color = max(skyColor, vec3(0.012, 0.018, 0.030));
            #if TONEMAPPING == 1
                aerial_color *= SUN_BRIGHTNESS * rtv_sky_illumination_factor();
            #endif
            color.rgb = mix(color.rgb, aerial_color, clamp(aerial_amount, 0.0, 0.09));
        }
    }

		#if TONEMAPPING == 1
		#if EXPOSURE == 0
			const float eyeBrightnessHalflife = 30.0;
			float exposure = mix(20.0, 32.0, clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0));
		#else
			float exposure = float(EXPOSURE);
		#endif
		float luminance = (color.r+ color.g+ color.b)/3.;
		color.rgb = color.rgb/(luminance+exposure);
		// Hue-preserving highlight compression: an over-exposed saturated colour (torch, lava, lamps, coloured glass light) used to clip
		// channel by channel and slide to yellow-white. Saturated over-range colours are now scaled down together, keeping their hue and saturation;
		// near-white values still clip as before.
		{
			float hp_max = max(max(color.r, color.g), color.b);
			float hp_min = min(min(color.r, color.g), color.b);
			float hp_chroma = (hp_max - hp_min) / max(hp_max, 0.0001);
			if(hp_max > 1.0) color.rgb = mix(color.rgb, color.rgb / hp_max, smoothstep(0.18, 0.50, hp_chroma));
		}
		//screen gamma
		color.rgb = linear_to_srgb(color.rgb);
		color.rgb = rtv_color_grade(color.rgb);
		if(isEyeInWater == 0 && VIGNETTE_STRENGTH > 0.0) // underwater has its own vignette
		{
			vec2 vg_p = (texcoord - 0.5) * vec2(viewWidth / max(viewHeight, 1.0), 1.0);
			color.rgb *= 1.0 - VIGNETTE_STRENGTH * smoothstep(0.30, 1.10, length(vg_p));
		}
	#endif
	
	
	#if RAYTRACING_VIEW > 0
        }//> close scope of where we ignore part of the screen that are going to be full RT view
//		else{
//			color=vec4(0.);//just write black here if you want to write something, it might become garbage data if you don't, I don't know
//		}
	#endif
	
	
	//Phone debug panels (Advanced > Phone Debug Panels). Three small squares in the top-left corner show which stage of the pipeline works:
	//  1 shadow map   : the sun's depth map. A solid white or solid black square means the shadow pass drew nothing.
	//  2 voxel slice  : the voxel scene around the player, seen from above at foot level. White = solid voxel, red dot = you.
	//                   All dark means nothing was voxelized; random noise means the voxel image holds garbage.
	//  3 light buffer : the ray traced light. Magenta pixels are NaN / Inf / out of range values.
	#if MOBILE_DEBUG_VIEW == 1
	{
		float dbg_size = 0.22;
		float dbg_gap = 0.02;
		vec2 dbg_p = vec2(texcoord.x * viewWidth / viewHeight, 1.0 - texcoord.y);
		for (int dbg_i = 0; dbg_i < 3; dbg_i++)
		{
			vec2 dbg_origin = vec2(dbg_gap + float(dbg_i) * (dbg_size + dbg_gap), dbg_gap);
			vec2 dbg_uv = (dbg_p - dbg_origin) / dbg_size;
			if (dbg_uv.x >= 0.0 && dbg_uv.x <= 1.0 && dbg_uv.y >= 0.0 && dbg_uv.y <= 1.0)
			{
				vec3 dbg_color = vec3(0.0);
				if (dbg_i == 0)
				{
					dbg_color = vec3(texture(shadowtex1, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).r);
				}
				if (dbg_i == 1)
				{
					ivec3 dbg_voxel = ivec3(clamp(int(dbg_uv.x * float(VOXEL_AREA)), 0, VOXEL_AREA - 1), VOXEL_AREA / 2 - 1, clamp(int(dbg_uv.y * float(VOXEL_AREA)), 0, VOXEL_AREA - 1));
					uint dbg_data = imageLoad(cimage1, dbg_voxel).r;
					dbg_color = dbg_data != 0u ? vec3(1.0) : vec3(0.0, 0.0, 0.2);
					if (length(dbg_uv - vec2(0.5)) < 0.02) dbg_color = vec3(1.0, 0.0, 0.0);
				}
				if (dbg_i == 2)
				{
					vec3 dbg_light = texture(LIGHT_SAMPLER, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).rgb;
					bool dbg_ok = dbg_light.r >= 0.0 && dbg_light.r <= 100000.0 && dbg_light.g >= 0.0 && dbg_light.g <= 100000.0 && dbg_light.b >= 0.0 && dbg_light.b <= 100000.0;
					dbg_color = dbg_ok ? clamp(dbg_light * 0.02, 0.0, 1.0) : vec3(1.0, 0.0, 1.0);
				}
				float dbg_edge = min(min(dbg_uv.x, dbg_uv.y), min(1.0 - dbg_uv.x, 1.0 - dbg_uv.y));
				color.rgb = dbg_edge < 0.012 ? vec3(1.0, 1.0, 0.0) : dbg_color;
			}
		}
	}
	#endif

	//Debug Area
		//color.rgb = fract(view_dir_world.rgb*10.);
		//color.rgb = fract(foot_pos+cameraPosition);
		//color.rgb = normals_face_world;
		//color.rgb = Dither_offset;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read) ) );
		//color.rgb = .5+.5*normals_texture_world;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read)/far ) );
	
}


