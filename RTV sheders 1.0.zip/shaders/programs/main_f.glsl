// Purpose
	// Main fragment shader:
		// defers data, so we can render the scene more efficiently later, without overdraw
	
// Our Settings
	#include "/stuff/settings.glsl"

// Data from minecraft / iris
	#ifdef MG_MOBILEGLUES
		// GLSL ES melarang initializer pada uniform. Variabel ini tidak dipakai, jadi cukup dideklarasikan.
		uniform float alphaTestRef;
	#else
		uniform float alphaTestRef=0.1;
	#endif
    uniform vec3 cameraPosition;
    uniform vec3 skyColor;
    uniform vec3 shadowLightPosition;
    uniform float frameTimeCounter;
	#if IS_AN_ENTITY == 1
		uniform vec4 entityColor;
	#endif
	#if IS_HAND == 1
		uniform int heldBlockLightValue;
		uniform int heldBlockLightValue2;
		uniform int heldItemId;
		uniform int heldItemId2;
		uniform int currentRenderedItemId;
	#endif

    uniform mat4 gbufferPreviousProjection;
    uniform mat4 gbufferPreviousModelView;
    uniform mat4 gbufferModelView;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferProjection;
    uniform mat4 gbufferProjectionInverse;

// Samplers / textures / images
    uniform sampler2D lightmap;
    uniform sampler2D gtexture;
    uniform sampler2D normals;
    uniform sampler2D specular;

	#if IS_WATER == 1 && IS_CLOUDS != 1 && WATER_WAVE_STYLE == 1
		#include "/stuff/water/unbound_water_waves.glsl"
	#endif

    //the 3d texture we are writing voxel data to
    layout (r32ui) uniform uimage3D cimage1;
    //our 3d image with interpolated voxel data
    uniform usampler3D cSampler1;

    //shadows
    uniform sampler2D shadowcolor0;
    uniform sampler2D shadowtex0;
    uniform sampler2D shadowtex1;



// Data we sent from vertex shader
    in vec2 lmcoord;
    in vec2 texcoord;
    in vec4 glcolor;
	
    in vec3 block_centered_relative_pos;
    in vec3 foot_pos2;
    in vec3 normals_face_world;
	in float material_id;
	in float emission_level;
	in vec4 tangent_world;



// Outputs: where we are rendering/sending data to

    /* RENDERTARGETS:1,2,3,4,5 */

    //this replaces fragdata[], you just set this variable to what you want to output
    //texture data
        layout(location = 0) out vec4 albedo_tex;
		const vec4 colortex1ClearColor = vec4( 0.0 , 0.0 , 0.0 , 0.0 );
		layout(location = 1) out vec4 specular_tex;
        layout(location = 2) out vec4 normals_tex;
    //other defered data
        layout(location = 3) out vec4 defered_data_1_tex; // vec4(lmcoord,ao,height_map); 
		layout(location = 4) out vec4 normals_face_world_and_material_id_tex; //normals_face_world, material id
		// Texture Buffer Formats
        /*
			const int colortex3Format = RGBA16F; 
			const int colortex5Format = RGBA16F; 
		*/

// Included files 
    //#include "/stuff/rt/rt.glsl"
    //#include "/stuff/space_transforms.glsl"
    //#include "/stuff/noise/noise_texture.glsl"



void main() {

    //defer texture data
        //albedo
	    albedo_tex = texture(gtexture, texcoord);
	    albedo_tex.rgb*=glcolor.rgb;
		#if IS_AN_ENTITY == 1
			albedo_tex.rgb = mix(albedo_tex.rgb, entityColor.rgb, entityColor.a);
		#endif
        
        #if NO_MIPS_IN_ALPHA == 1
    	    albedo_tex.a = textureLod(gtexture, texcoord,0).a;
        #endif
        if(albedo_tex.a < .01 ) discard;
	       
        //specular
        specular_tex = texture(specular, texcoord); 
        specular_tex.a = fract(specular_tex.a);//decode alpha of 1.0 as 0 emission
		//light blocks glow themselves, mostly on their bright parts (flame, lamp surface)
		specular_tex.a = max(specular_tex.a, emission_level * smoothstep(0.35, 0.75, dot(albedo_tex.rgb, vec3(0.3333))));

			
		//normals
        normals_tex = texture(normals, texcoord); 
		float ao = normals_tex.b;
		float height_map = normals_tex.a;
		normals_tex.xy=normals_tex.xy*2.-1.;
		normals_tex.z = sqrt(1.0-dot(normals_tex.xy, normals_tex.xy)); //Reconstruct Z
		
        //intergrated pbr
		#if IS_WATER == 1 && IS_CLOUDS != 1
		    if (abs(material_id - 1.0) < 0.5)
		    {
		        specular_tex = vec4(0.98, WATER_REFLECTION_STRENGTH, 1.0, 0.0); // water: clear, smooth ray-traced reflections
		        // Clear blue-cyan water. Keep the biome tint restrained so the surface
		        // and underwater volume share one hue family instead of turning pale green.
		        vec3 water_surface_base = mix(vec3(0.72, 0.88, 0.94), vec3(0.16, 0.43, 0.60), WATER_TINT);
		        albedo_tex.rgb = mix(water_surface_base, glcolor.rgb, 0.14);
		    }
		#else
		    if (abs(material_id - 1.0) < 0.5) specular_tex = vec4(1.0, 0.02, 1.0, 0.0);
		#endif
		#if IPBR_MIRRORS == 1
			if( abs(material_id - 2.) < .5 ) //metals
            {
                // Polished metal, but not a perfect mirror: a little roughness softens the reflection.
                specular_tex = vec4(0.82,0.93,0.0,0.0);
                normals_tex = vec4(0.,0.,1.,1.); 
            }
			if( abs(material_id - 3.) < .5 ) // clear / stained glass and glass panes
            {
                specular_tex = vec4(0.99, GLASS_REFLECTION_STRENGTH, 0.0, 0.0);
                normals_tex = vec4(0.,0.,1.,1.);
            }
        #endif

        // Small PBR-driven reflections on building blocks (IDs 50 / 52) and cave crystals / gems (51, 12, 11, gem ores 10).
        // Only these materials get a sheen: dirt, grass, natural stone, wood logs and so on stay matte.
        // If the resource pack ships a LabPBR specular map its smoothness / F0 is used (so every texel keeps its own gloss);
        // without one, a procedural fallback derives the gloss from the albedo and the normal map, so the surface is never flat.
        #if MATERIAL_REFLECTIONS == 1 && IS_AN_ENTITY != 1 && IS_HAND != 1 && IS_CLOUDS != 1 && IS_WATER != 1
        {
            float mr_hard    = abs(material_id - 50.0) < 0.5 ? 1.0 : 0.0;
            float mr_soft    = abs(material_id - 52.0) < 0.5 ? 1.0 : 0.0;
            float mr_crystal = (abs(material_id - 51.0) < 0.5 || abs(material_id - 12.0) < 0.5 || abs(material_id - 11.0) < 0.5) ? 1.0 : 0.0;
            float mr_ore     = abs(material_id - 10.0) < 0.5 ? 1.0 : 0.0;
            float mr_luma    = dot(albedo_tex.rgb, vec3(0.2126, 0.7152, 0.0722));
            // gem ores: only the bright mineral specks glint, the surrounding stone stays rough
            float mr_ore_mask = mr_ore * smoothstep(0.38, 0.70, mr_luma);
            float mr_any = max(max(mr_hard, mr_soft), max(mr_crystal, mr_ore_mask));
            if (mr_any > 0.001)
            {
                bool mr_has_pbr = (specular_tex.r + specular_tex.g) > 0.02 && specular_tex.g < 229.6 / 255.0;
                // procedural fallback (no specular map)
                float mr_slope  = length(normals_tex.xy);                        // tilted normal-map texels = grout, cracks, bevels
                float mr_detail = 1.0 - 0.75 * smoothstep(0.08, 0.45, mr_slope);   // those texels stay rougher
                float mr_dirty  = mix(0.55, 1.0, smoothstep(0.10, 0.55, mr_luma)); // dark / dirty texels are less glossy
                float mr_smooth = mr_hard * 0.66 + mr_soft * 0.40 + max(mr_crystal, mr_ore_mask) * 0.90;
                float mr_f0     = mr_hard * 0.060 + mr_soft * 0.030 + mr_crystal * 0.100 + mr_ore_mask * 0.090;
                mr_smooth *= mr_detail * mr_dirty;
                mr_f0     *= mr_detail * mr_dirty;
                if (mr_has_pbr)
                {
                    // resource-pack PBR: keep its per-texel smoothness, give dielectrics at least a small F0
                    mr_smooth = clamp(specular_tex.r * mix(1.0, 1.15, mr_crystal), 0.0, 0.98);
                    mr_f0     = max(specular_tex.g, mr_f0 * 0.6);
                }
                float mr_strength = mix(BUILDING_REFLECTION_STRENGTH, CRYSTAL_REFLECTION_STRENGTH, max(mr_crystal, mr_ore_mask));
                specular_tex.r = clamp(mr_smooth, 0.0, 0.98);
                specular_tex.g = clamp(mr_f0 * mr_strength, 0.0, 0.5);
                // normals_tex is left untouched on purpose: the reflection follows the PBR normal map instead of a flat plane.
            }
        }
        #endif

        // Final matte guard after optional mirror overrides: held hands/tools should not
        // become glossy from a material ID, and dropped/entity models keep only a faint sheen.
        // Water and spider-eye passes are intentionally left untouched.
        #if IS_HAND == 1 && IS_HAND_WATER != 1
            specular_tex.r = 0.0;
            specular_tex.g = 0.0;
        #elif IS_AN_ENTITY == 1 && IS_SPIDER_EYES != 1
            specular_tex.r *= 0.20;
            specular_tex.g *= 0.025;
        #endif

		//convert normals to world space
		vec3 tangent2 = normalize(cross(tangent_world.rgb,normals_face_world.xyz)*tangent_world.w);
		mat3 tbn_matrix = mat3(tangent_world.xyz, tangent2.xyz, normals_face_world.xyz);
		normals_tex.xyz = normalize(tbn_matrix * normals_tex.xyz); //Rotate by TBN matrix

		// Fine, narrow, world-locked ripples on the horizontal water surface.
		#if IS_WATER == 1 && IS_CLOUDS != 1
		    #if WATER_WAVE_STYLE == 1
		        // gaya Unbound: hanya untuk air asli, bukan kaca/es yang ikut lewat program water
		        if (normals_face_world.y > 0.55 && abs(material_id - 1.0) < 0.5)
		    #else
		        if (normals_face_world.y > 0.55)
		    #endif
		    {
		        vec3 water_world_pos = foot_pos2 + cameraPosition;
		        vec2 water_xz = water_world_pos.xz;
		        #if WATER_WAVE_STYLE == 1
		            // Gelombang air Unbound: ombak lebar + caustic + sinus berlapis, normal = gradien medan tinggi.
		            // WATER_WAVE_STRENGTH 0.055 = kekuatan sedang; ~0.14 mendekati kekuatan asli di Unbound.
		            vec2 wave_slope = uww_water_slope(water_xz, frameTimeCounter) * (WATER_WAVE_STRENGTH * 3.0);
		            normals_tex.xyz = normalize(normals_tex.xyz + vec3(-wave_slope.x, 0.0, -wave_slope.y));
		        #else
		            float wave_time = frameTimeCounter * WATER_WAVE_SPEED;
		            float wave_x = sin(water_xz.x * 0.78 + water_xz.y * 0.31 + wave_time * 0.78)
		                         + sin(water_xz.x * 0.42 - water_xz.y * 0.86 - wave_time * 0.58)
		                         + 0.28 * sin(water_xz.x * 1.85 + water_xz.y * 1.37 + wave_time * 1.15);
		            float wave_z = cos(water_xz.y * 0.74 - water_xz.x * 0.38 + wave_time * 0.72)
		                         + cos(water_xz.y * 0.47 + water_xz.x * 0.62 - wave_time * 0.54)
		                         + 0.28 * cos(water_xz.y * 1.72 - water_xz.x * 1.46 - wave_time * 1.04);
		            vec3 wave_normal = normalize(vec3(wave_x * WATER_WAVE_STRENGTH, 1.0,
		                                              wave_z * WATER_WAVE_STRENGTH));
		            normals_tex.xyz = normalize(mix(normals_tex.xyz, wave_normal, 0.32));
		        #endif
		    }
		#endif

		// Clear, stained and thin glass: smooth RT reflections with dielectric Fresnel.
		// Neutral / white glass receives a faint cool-white tint; stained glass keeps its own hue.
		if (abs(material_id - 3.0) < 0.5)
		{
		    float glass_peak = max(max(albedo_tex.r, albedo_tex.g), albedo_tex.b);
		    float glass_min = min(min(albedo_tex.r, albedo_tex.g), albedo_tex.b);
		    float glass_saturation = (glass_peak - glass_min) / max(glass_peak, 0.025);
		    float clear_glass_mask = 1.0 - smoothstep(0.08, 0.28, glass_saturation);
		    vec3 clear_glass_color = vec3(0.86, 0.94, 1.00);
		    albedo_tex.rgb = mix(albedo_tex.rgb, clear_glass_color, CLEAR_GLASS_TINT * clear_glass_mask);
		    // Slightly stronger reflection at face-on angles; Fresnel adds more at grazing angles.
		    specular_tex = vec4(0.99, GLASS_REFLECTION_STRENGTH, 0.0, 0.0);
		    // Keep the glass ray transmissive while ensuring it participates in reflection / refraction.
		    albedo_tex.a = min(albedo_tex.a, 0.975);
		}
		if (abs(material_id - 4.0) < 0.5)
		{
		    albedo_tex.rgb = mix(albedo_tex.rgb, vec3(0.015, 0.070, 0.18), 0.48);
		    albedo_tex.a = min(albedo_tex.a, 0.94);
		    specular_tex = vec4(0.96, 0.34, 0.0, 0.0); // ice: smooth, with a strong base reflectivity so ALL faces (top and sides) mirror their surroundings
		}

		// Gentle animated, world-locked refraction waves. The slow motion resembles water distortion
		// without introducing fast screen-space shimmer or moving noise.
		#if IS_CLOUDS != 1
		    if ((abs(material_id - 3.0) < 0.5 || abs(material_id - 4.0) < 0.5) && GLASS_DISTORTION > 0.0)
		    {
		        vec3 glass_world_pos = foot_pos2 + cameraPosition;
		        vec3 glass_axis = abs(normals_face_world);
		        vec2 gw = glass_axis.y > 0.5 ? glass_world_pos.xz : (glass_axis.x > 0.5 ? glass_world_pos.zy : glass_world_pos.xy);
		        float glass_time = frameTimeCounter * 0.10;
		        vec2 glass_off = vec2(
		            sin(gw.x * 1.15 + gw.y * 0.72 + glass_time) + 0.24 * sin(gw.y * 2.05 - gw.x * 1.31 - glass_time * 0.68),
		            cos(gw.y * 1.07 - gw.x * 0.83 - glass_time * 0.82) + 0.22 * cos(gw.x * 1.76 + gw.y * 1.19 + glass_time * 0.61)
		        );
		        vec3 glass_u = glass_axis.y > 0.5 ? vec3(1., 0., 0.) : vec3(0., 1., 0.);
		        vec3 glass_v = normalize(cross(normals_face_world, glass_u));
		        float is_ice_material = abs(material_id - 4.0) < 0.5 ? 1.0 : 0.0;
		        float material_distortion = mix(0.95, 1.25, is_ice_material);
		        normals_tex.xyz = normalize(normals_tex.xyz + (GLASS_DISTORTION * material_distortion) * (glass_off.x * glass_u + glass_off.y * glass_v));
		    }
		#endif

		// ---- glowing things: ores, crying obsidian, amethyst, sculk, particles, held light items ----
		// Emission is added after the denoiser (EMISSION_STRENGTH * BLOCK_LIGHT_BRIGHTNESS), so values here are small fractions.
		{
			float g_max = max(albedo_tex.r, max(albedo_tex.g, albedo_tex.b));
			float g_min = min(albedo_tex.r, min(albedo_tex.g, albedo_tex.b));
			float g_sat = (g_max - g_min) / (g_max + 0.02);
			float g_lum = dot(albedo_tex.rgb, vec3(0.2126, 0.7152, 0.0722));
			float g_emit = 0.0;
			float g_t = frameTimeCounter;

			#if IS_AN_ENTITY != 1 && IS_HAND != 1 && IS_TEXTURED != 1 && IS_TEXTURED_LIT != 1
				vec3 g_block = floor(block_centered_relative_pos + floor(cameraPosition));   // the block this face belongs to
				float g_h = fract(sin(dot(g_block, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
				#if GLOWING_ORES == 1
					if (abs(material_id - 10.0) < 0.5)
					{
						// stone is grey (low saturation, mid brightness): only the mineral specks glow
						float ore_mask = max(smoothstep(0.30, 0.55, g_sat), smoothstep(0.62, 0.85, g_lum));
						float sparkle = 0.85 + 0.15 * sin(g_t * 1.7 + g_h * 6.2831);
						g_emit = ore_mask * GLOWING_ORES_STRENGTH * sparkle;
					}
				#endif
				#if PULSING_BLOCKS == 1
					if (abs(material_id - 11.0) < 0.5)            // crying obsidian: slow pulse, bright purple veins glow most
					{
						float pulse = 0.5 + 0.5 * sin(g_t * 1.6 + g_h * 6.2831);
						float vein = smoothstep(0.18, 0.50, g_lum + 0.5 * g_sat);
						g_emit = (0.06 + 0.34 * vein) * (0.35 + 0.65 * pulse);
					}
					else if (abs(material_id - 12.0) < 0.5)       // amethyst: travelling shimmer
					{
						vec3 g_wp = foot_pos2 + cameraPosition;
						float shimmer = 0.55 + 0.45 * sin(g_t * 1.3 + g_h * 6.2831 + (g_wp.x + g_wp.y + g_wp.z) * 0.9);
						g_emit = smoothstep(0.30, 0.70, g_lum + 0.3 * g_sat) * 0.20 * shimmer;
					}
					else if (abs(material_id - 13.0) < 0.5)       // sculk: slow bioluminescent wave
					{
						vec3 g_wp = foot_pos2 + cameraPosition;
						float wave = 0.5 + 0.5 * sin(g_t * 0.9 - dot(g_wp, vec3(0.35, 0.20, 0.35)) + g_h * 2.0);
						float spot = smoothstep(0.22, 0.50, albedo_tex.b + 0.5 * albedo_tex.g - albedo_tex.r);
						g_emit = spot * 0.30 * (0.35 + 0.65 * wave);
					}
				#endif
			#endif

			#if IS_TEXTURED == 1 || IS_TEXTURED_LIT == 1
				// particles: bright / saturated pixels glow (flame, portal, enchanting glyphs, firework sparks, dragon breath...)
				g_emit = smoothstep(0.30, 0.75, max(g_lum, g_sat * 0.85)) * 0.55 * PARTICLE_GLOW * albedo_tex.a;
			#endif

			#if IS_HAND == 1 && HELD_ITEM_GLOW == 1
				{
					float hand_level = float(max(heldBlockLightValue, heldBlockLightValue2));
					if (currentRenderedItemId > 0)
						hand_level = float(currentRenderedItemId == heldItemId ? heldBlockLightValue : (currentRenderedItemId == heldItemId2 ? heldBlockLightValue2 : 0));
					float hand_mask = smoothstep(0.35, 0.75, g_lum + 0.4 * g_sat);   // the flame / lamp surface, not the stick
					g_emit = clamp(hand_level / 15.0, 0.0, 1.0) * hand_mask * 0.55 * HELD_LIGHT_BRIGHTNESS;
				}
			#endif

			specular_tex.a = max(specular_tex.a, g_emit);
		}

		//defer other data we want
        defered_data_1_tex = vec4(lmcoord,ao,height_map);
		
		#if IS_HAND == 1
			float material_mask_id = 101.0;
		#elif IS_AN_ENTITY == 1
			float material_mask_id = 100.0;
		#else
            #if IS_CLOUDS == 1
                float material_mask_id = 41.;
            #else
			    float material_mask_id = material_id;
            #endif
		#endif
		
		normals_face_world_and_material_id_tex = vec4(normals_face_world.xyz, material_mask_id);
		
	// Debug Area
		//specular_tex = vec4(1.,0.,0.,1.);//debug
		
}//> main
