// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


// Purpose:
	// RT View Pass: 
		// Debug View of voxelized data via a Ray trace from the camera

// Our Settings
	#include "/stuff/settings.glsl"

// Uniforms: data from iris & minecraft:
    uniform vec3 cameraPosition;
    uniform vec3 previousCameraPosition;
    uniform vec3 skyColor;
    uniform vec3 sunPosition;
    uniform float centerDepthSmooth;
    uniform bool hideGUI;
    uniform float near,far;
    uniform vec3 shadowLightPosition;
	uniform ivec2 eyeBrightnessSmooth;


    //space transforms
		//are moved into "/stuff/space_transforms.glsl"

  
// Samplers / Textures / Images
    //working scene image
    uniform sampler2D colortex0;

    //the 3d texture we are writing voxel data to
    layout (r32ui) uniform uimage3D cimage1;

// data from the vertex shader
    in vec2 texcoord;

// Outputs
    /* DRAWBUFFERS:0 */
    layout(location = 0) out vec4 color;

// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;
	
// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
    #define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/misc_functions.glsl"


// Functions:

    // Halton sequence generator
    //concept by John Halton in 1960 (if Google can be trusted)
    vec2 halton(int index, int base1, int base2)
    {
        float result1 = 0.0;
        float f1 = 1.0 / float(base1);
        int i1 = index;
        while (i1 > 0) {
            result1 += f1 * float(mod(float(i1), float(base1)));
            i1 = int(float(i1) / float(base1));
            f1 /= float(base1);
        }

        float result2 = 0.0;
        float f2 = 1.0 / float(base2);
        int i2 = index;
        while (i2 > 0) {
            result2 += f2 * float(mod(float(i2), float(base2)));
            i2 = int(float(i2) / float(base2));
            f2 /= float(base2);
        }

        return vec2(result1, result2);
    }


    float linearize_depth(in float d)
    {
	    // from gl_FragCoord.z to world measurements
	    return 2.0 * near  * far / (far + near - (2.0 * d - 1.0) * (far - near));

    }


    float rand(float n){return fract(sin(n) * 43758.5453123);}

    float rand(vec2 n) { 
	    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
    }
	    
    float noise(vec2 n) {
	    const vec2 d = vec2(0.0, 1.0);
      vec2 b = floor(n), f = smoothstep(vec2(0.0), vec2(1.0), fract(n));
	    return mix(mix(rand(b), rand(b + d.yx), f.x), mix(rand(b + d.xy), rand(b + d.yy), f.x), f.y);
    }







//main function

void main() {
    //load the result of the gbuffers rasterizing to start with
	color = texture(colortex0, texcoord);

    #if RAYTRACING_VIEW > 0
		#if RAYTRACING_VIEW == 1
        //we are only ray tracing the right half of the screen
        if(texcoord.x>.5)
		#endif
        {
			//Load a Dither / Randomness / Offset
				Dither_offset = blue_noise().xyz;
		
			//get Sun direction in the world
				Sun_or_moon_dir_world = normalize(
						view_to_foot_direction(shadowLightPosition)
						#if SOFT_RT_SHADOWS == 1
							+ SUN_WIDTH * (2.*Dither_offset.xyz-1.)
						#endif
					);
		

            //get ray direction from camera

               vec3 direction_world;
               { //scoped to remove variables from memory as soon as we don't need them anymore
                    vec3 direction_screen = vec3(texcoord, 1.);//texture(depthtex0,texcoord).r);//doing direction here, not position
                    vec3 direction_view = screen_to_view_space(direction_screen);
                    direction_world = normalize(view_to_foot_direction( direction_view ) );
                }


            //get ray starting position

                 vec3 eye_position = vec3(0.) 
                    + gbufferModelViewInverse[3].xyz //view bob
                    + direction_world * STUPID_RT_BIAS_IRIS_BUG;//this bias seems to be necesary because of an iris bug. Iris isn'y properly filling the renderStage uniform to let us remove entities like the player from the voxelizing. because of this, many rays will hit the player before leaving the camera, unless we add this bias. This is stupid and should hopefully be fixed in iris
            

            //trace ray
                Traced_ray traced_ray = trace_ray(eye_position, direction_world);
                // show result on screen
                color.rgb =	traced_ray.albedo.rgb;
					
			//Tonemapping, to make HDR image data look good on a screen		
				#if TONEMAPPING == 1
					#if EXPOSURE == 0
						const float eyeBrightnessHalflife = 30.0;
						float exposure = mix(18.0, 30.0, clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0));
					#else
						float exposure = float(EXPOSURE);
					#endif
					float luminance = (color.r+ color.g+ color.b)/3.;
					color.rgb = color.rgb/(luminance+exposure);
					//screen gamma
					color.rgb = linear_to_srgb(color.rgb);
				#endif
				
        }//> texcoord.x > .5, or inside of where to trace
    #endif

}//> main


